#!/usr/bin/env bash
set -e

mapper="RefImpl"
json="minimal-message.json"

# send to mapper
#
docker-compose exec mapper-service-client-cli mapper-service-client-cli --mapper $mapper --file $(pwd)/$json
