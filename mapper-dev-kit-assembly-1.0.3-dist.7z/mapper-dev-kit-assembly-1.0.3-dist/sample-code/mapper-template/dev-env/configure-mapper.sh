#!/usr/bin/env bash
set -e

mapper="RefImpl"
tenant="TENANT1"
version=1

docker-compose exec mapper-config-cli mapper-config-cli version set -m $mapper -t $tenant -r Simulator -v $version
docker-compose exec mapper-config-cli mapper-config-cli config set -m $mapper -t $tenant -r Simulator -d $(pwd)/mapper-config.json
