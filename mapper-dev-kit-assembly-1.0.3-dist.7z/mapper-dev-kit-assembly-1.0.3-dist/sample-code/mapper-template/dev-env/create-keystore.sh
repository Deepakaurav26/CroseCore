#!/usr/bin/env bash

keytool -keystore keystore-zookeeper.jks -storepass password -genkey -keypass password -alias zk1 -dname "CN=test,OU=test,O=test,L=test,ST=test,C=test" -sigalg SHA256withRSA -keyalg RSA -keysize 2048
