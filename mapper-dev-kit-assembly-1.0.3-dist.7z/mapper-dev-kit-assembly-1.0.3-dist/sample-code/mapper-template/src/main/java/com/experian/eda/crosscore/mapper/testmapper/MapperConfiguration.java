package com.experian.eda.crosscore.mapper.testmapper;

import lombok.NonNull;
import lombok.Value;

@Value
public class MapperConfiguration {

  // TODO: add configuration fields & validation (this is just a sample)

  @NonNull
  String endpoint;
}
