package com.experian.eda.crosscore.mapper.testmapper;

import com.experian.eda.crosscore.mapper.api.exceptions.MapperException;
import com.experian.eda.crosscore.standardmapper.Transporter;

public class MyTransporter implements Transporter<Object, Object, MapperConfiguration> {

  @Override
  public Object transport(final Object transformerResult, final MapperConfiguration config) throws MapperException {

    // TODO business logic goes here

    return null;
  }

  @Override
  public void close() throws Exception {
    // do nothing
  }
}
