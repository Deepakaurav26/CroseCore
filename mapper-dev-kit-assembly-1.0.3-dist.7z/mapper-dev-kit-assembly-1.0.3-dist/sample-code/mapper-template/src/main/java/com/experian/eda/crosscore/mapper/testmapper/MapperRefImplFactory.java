package com.experian.eda.crosscore.mapper.testmapper;

import com.experian.eda.crosscore.mapper.api.MapperFactory;
import com.experian.eda.crosscore.mapper.api.MapperInformation;
import com.experian.eda.crosscore.mapper.api.Services;
import com.experian.eda.crosscore.standardmapper.ParsingTransformer;
import com.experian.eda.crosscore.standardmapper.PojoConfigurationReader;
import com.experian.eda.crosscore.standardmapper.StandardMapper;

import java.util.Collections;

/**
 * Factory providing a template/reference implementation.
 */
public class MapperRefImplFactory implements MapperFactory<StandardMapper> {

  public StandardMapper createMapper(final Services services) {
    return new StandardMapper<>(
        new PojoConfigurationReader<>(MapperConfiguration.class),
        new ParsingTransformer<>(new MyTransformer()),
        new MyTransporter(),
        new MyResponseGenerator()
    );
  }

  @Override
  public MapperInformation getMapperInformation() {
    return MapperInformation
        .builder()
        .name("RefImpl") // TODO: provide name
        .supportedBackingApplicationVersions(Collections.singletonList("1")) // TODO: provide version
        .build();
  }
}
