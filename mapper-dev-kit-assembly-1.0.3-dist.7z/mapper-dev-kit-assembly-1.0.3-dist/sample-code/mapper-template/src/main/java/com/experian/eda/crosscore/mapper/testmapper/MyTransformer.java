package com.experian.eda.crosscore.mapper.testmapper;

import com.experian.eda.crosscore.api.request.RequestMessage;
import com.experian.eda.crosscore.mapper.api.exceptions.MapperException;
import com.experian.eda.crosscore.standardmapper.Transformer;
import com.experian.eda.crosscore.standardmapper.request.RequestContainer;
import com.experian.eda.crosscore.standardmapper.request.RestPostRequestContainer;

public class MyTransformer implements Transformer<RequestMessage, Object, MapperConfiguration> {

  @Override
  public RequestContainer transformRequest(final RequestMessage requestMessage, final MapperConfiguration config)
      throws MapperException {

    // TODO business logic goes here

    return null;
  }

  @Override
  public void close() throws Exception {
    // do nothing
  }
}
