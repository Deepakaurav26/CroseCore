package com.experian.eda.crosscore.mapper.testmapper;

import com.experian.eda.crosscore.api.decisionElements.DecisionElements;
import com.experian.eda.crosscore.mapper.api.MapperResponse;
import com.experian.eda.crosscore.mapper.api.exceptions.MapperException;
import com.experian.eda.crosscore.standardmapper.ResponseGenerator;

import java.util.Arrays;
import java.util.Collections;

public class MyResponseGenerator implements ResponseGenerator<Object, MapperConfiguration> {

  @Override
  public MapperResponse generateResponse(final Object transporterResult, final MapperConfiguration config)
      throws MapperException {

    // TODO business logic goes here

    return MapperResponse
        .builder()
        .decisionElements(Collections.singletonList(
            DecisionElements
                .builder()
                .decision("ok")
                .build()
        ))
        .strategyResponse(Arrays.asList("ok"))
        .build();
  }

  @Override
  public void close() throws Exception {
    // do nothing
  }
}
