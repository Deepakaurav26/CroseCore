package com.experian.eda.crosscore.standardmapper.request;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NonNull;
import lombok.val;
import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.RequestBody;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

/**
 * A {@link RequestContainer} that represents an HTTP request with a method of POST.
 * Intended to be passed to {@link RestTransporter#transport} (or returned from a {@link Transformer} if the
 * {@link Transporter} is {@link RestTransporter}).
 */
@Getter
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class RestPostRequestContainer<Body, Context> implements RequestContainer<Context> {

  private static final MediaType MEDIA_TYPE = MediaType.parse("application/json; charset=utf-8");

  /**
   * POST Request body that is passed to the restTransporter in the form of type {@code Body} which is serialized to byte[]
   */
  @NonNull
  private final Body body;
  /**
   * Headers in the form of Map that are passed to the restTransporter
   */
  private final Map<String, List<String>> headers;
  private final Context context;
  /**
   * endpoint value for backing app rest service that is called by httpClient.
   */
  @NonNull
  private final String endPoint;

  /**
   *
   * @param objectMapper converts the request body of type {@code Body} to byte[] which is then used by
   *                     {@code Request#Builder) to create an OkHttp Request object
   * @return OkHttp POST Request object with body, headers and endpoint
   */
  @Override
  public Request buildRequest(final ObjectMapper objectMapper) throws JsonProcessingException {
    final byte[] bodyBytes;
    if (getBody() instanceof byte[]) {
      bodyBytes = (byte[]) getBody();
    } else if (getBody() instanceof String) {
      bodyBytes = ((String) getBody()).getBytes(StandardCharsets.UTF_8);
    } else {
      bodyBytes = objectMapper.writeValueAsBytes(getBody());
    }

    val builder = new Request.Builder();
    if (getHeaders() != null) {
      for (val entry : getHeaders().entrySet()) {
        for (val value : entry.getValue()) {
          builder.addHeader(entry.getKey(), value);
        }
      }
    }
    return builder
        .post(RequestBody.create(MEDIA_TYPE, bodyBytes))
        .url(getEndPoint())
        .build();
  }
}
