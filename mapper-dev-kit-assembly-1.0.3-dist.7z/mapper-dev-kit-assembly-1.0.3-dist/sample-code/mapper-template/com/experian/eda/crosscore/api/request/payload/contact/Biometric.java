package com.experian.eda.crosscore.api.request.payload.contact;

import com.experian.eda.crosscore.api.validation.NotNullElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import javax.validation.Valid;

/**
 * Class representing the Biometric JSON object in a CrossCore message.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Biometric {

  private String metaPip;
  private String metaLot;
  private String metaLov;
  private String metaFdc;
  private String biosVerificationTkn;
  @Valid
  private List<@NotNullElement BiometricData> biometricData;
  @Valid
  private List<@NotNullElement Image> images;
}
