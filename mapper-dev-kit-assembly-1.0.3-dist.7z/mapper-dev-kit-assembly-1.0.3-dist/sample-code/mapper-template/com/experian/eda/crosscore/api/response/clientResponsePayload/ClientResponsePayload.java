package com.experian.eda.crosscore.api.response.clientResponsePayload;

import com.experian.eda.crosscore.api.request.payload.DecisionElementsWithServiceName;
import com.experian.eda.crosscore.api.validation.NotNullElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import javax.validation.Valid;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ClientResponsePayload {

  @Valid
  private List<@NotNullElement OrchestrationDecision> orchestrationDecisions;
  @Valid
  private List<@NotNullElement DecisionElementsWithServiceName> decisionElements;

}
