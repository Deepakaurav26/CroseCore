package com.experian.eda.crosscore.api.request.payload.contact;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class representing the Address JSON object in a CrossCore message.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Address {

  private String id;
  private String addressIdentifier;
  private String indicator;
  private String addressType;
  private String poBoxNumber;
  private String subBuilding;
  private String buildingName;
  private String buildingNumber;
  private String street;
  private String street2;
  private String subLocality;
  private String postTown;
  private String county;
  private String postal;
  private String stateProvinceCode;
  private String countryCode;
  private ResidentFrom residentFrom;
  private ResidentTo residentTo;
  private TimeSpan timeAtAddress;
  private MonetaryAmount propertyValue;
  private String careOfName;
  private String locality;
  private String postOfficeName;
  private String propertyType;
  private MonetaryAmount purchasePrice;
  private String landmark;
  private Integer buildingAge;
  private String typeOfHouse;
  private String buildingConstruction;
  private MonetaryAmount rebuildValue;
  private Integer noOfBedrooms;
  private Integer noOfReceptionRooms;
  private Integer noOfBathrooms;
  private Integer noOfOtherRooms;
  private String ownOrRent;
  private String isUsedForBusiness;
  private Integer noOfResidents;
  private MonetaryAmount valueOfContents;
  private MonetaryAmount highRiskItemValue;
  private String windowDoorLocks;
  private Boolean burglarAlarm;
  private Integer maxDaysEmpty;
  private String riskOfFlooding;

  public static class AddressType {

    private AddressType() {}

    public static final String BILLING = "BILLING";
    public static final String CORRESPONDANCE = "CORRESPONDANCE";
    public static final String CURRENT = "CURRENT";
    public static final String DELIVERY = "DELIVERY";
    public static final String GARAGE = "GARAGE";
    public static final String INCIDENT_LOCATION = "INCIDENT_LOCATION";
    public static final String INSPECTION_ADDRESS = "INSPECTION_ADDRESS";
    public static final String INSURED_ADDRESS = "INSURED_ADDRESS";
    public static final String LINKED = "LINKED";
    public static final String PREVIOUS = "PREVIOUS";
    public static final String PRIMARY = "PRIMARY";
    public static final String REGISTERED_OFFICE = "REGISTERED_OFFICE";
    public static final String RISK = "RISK";
    public static final String SECONDARY = "SECONDARY";
    public static final String TRADING = "TRADING";
  }

  public static class Indicator {

    private Indicator() {}

    public static final String COMMERCIAL = "COMMERCIAL";
    public static final String NON_RESIDENTIAL = "NON_RESIDENTIAL";
    public static final String OTHER = "OTHER";
    public static final String RESIDENTIAL = "RESIDENTIAL";
    public static final String UNKNOWN = "UNKNOWN";
  }

  public static class PropertyType {

    private PropertyType() {}

    public static final String BUNGALOW = "BUNGALOW";
    public static final String COTTAGE = "COTTAGE";
    public static final String DETACHED = "DETACHED";
    public static final String FLAT = "FLAT";
    public static final String LAND = "LAND";
    public static final String MAISONETTE = "MAISONETTE";
    public static final String NOT_KNOWN = "NOT_KNOWN";
    public static final String OTHER = "OTHER";
    public static final String PURPOSE_BUILT = "PURPOSE_BUILT";
    public static final String SEMI_DETATCHED = "SEMI_DETATCHED";
    public static final String TERRACED = "TERRACED";
  }
}
