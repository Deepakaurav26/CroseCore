package com.experian.eda.crosscore.api.decisionElements.contact;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@FieldDefaults(level = AccessLevel.PRIVATE)
@Builder
public class IdentityDocument {

  private String id;
  private String documentNumber;
  private String hashedDocumentNumber;
  private String documentType;
  private List<Image> images;

  public static class DocumentType {

    private DocumentType() {}

    public static final String AADHAR = "AADHAR";
    public static final String COMPANY_TAN = "COMPANY_TAN";
    public static final String DRIVER_LICENSE = "DRIVER_LICENSE";
    public static final String ECINUMBER = "ECINUMBER";
    public static final String IDCARD = "IDCARD";
    public static final String MEDICARE = "MEDICARE";
    public static final String NATIONAL_ID = "NATIONAL_ID";
    public static final String NATIONAL_INSURANCE = "NATIONAL_INSURANCE";
    public static final String PAN = "PAN";
    public static final String PASSPORT = "PASSPORT";
    public static final String PERSONAL_NUMBER = "PERSONAL_NUMBER";
    public static final String SIN = "SIN";
    public static final String SSN = "SSN";
    public static final String TAX_NUMBER = "TAX_NUMBER";
    public static final String TRAVEL_VISA = "TRAVEL_VISA";
    public static final String VOTER_ID = "VOTER_ID";
  }
}
