package com.experian.eda.crosscore.standardmapper.request;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;
import lombok.val;
import okhttp3.Request;

import java.util.List;
import java.util.Map;

/**
 * A {@link RequestContainer} that represents an HTTP request with a method of GET.
 * Intended to be passed to {@link RestTransporter#transport} (or returned from a {@link Transformer} if the
 * {@link Transporter} is {@link RestTransporter}).
 */
@Getter
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class RestGetRequestContainer<Context> implements RequestContainer<Context> {

  private final Map<String, List<String>> headers;
  private final Context context;
  @NonNull
  private final String endPoint;

  /**
   *
   * @param objectMapper Instance of {@link ObjectMapper}. Not used.
   * @return OkHttp GET Request object with headers and endpoint
   */
  @Override
  public Request buildRequest(final ObjectMapper objectMapper) throws JsonProcessingException {
    val builder = new Request.Builder();

    if (getHeaders() != null) {
      for (val entry : getHeaders().entrySet()) {
        for (val value : entry.getValue()) {
          builder.addHeader(entry.getKey(), value);
        }
      }
    }
    builder.get();
    builder.url(getEndPoint());
    return builder.build();
  }
}