package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.request.payload.contact.MonetaryAmount;
import com.fasterxml.jackson.annotation.JsonUnwrapped;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Charges {

  private String type;
  @JsonUnwrapped
  private MonetaryAmount monetaryAmount;

  public static class Type {

    private Type() {}

    public static final String ONE_OFF = "ONE_OFF";
  }
}
