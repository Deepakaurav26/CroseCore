package com.experian.eda.crosscore.api.decisionElements.contact;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@FieldDefaults(level = AccessLevel.PRIVATE)
@Builder
public class Name {

  private String id;
  private String type;
  private String givenNames;
  private String firstName;
  private String middleNames;
  private String surName;

  public static class Type {

    private Type() {}

    public final static String ALIAS = "ALIAS";
    public final static String CURRENT = "CURRENT";
    public final static String FATHER = "FATHER";
    public final static String HUSBAND = "HUSBAND";
    public final static String MAIDEN = "MAIDEN";
    public final static String OTHER = "OTHER";
    public final static String PREVIOUS = "PREVIOUS";
  }
}
