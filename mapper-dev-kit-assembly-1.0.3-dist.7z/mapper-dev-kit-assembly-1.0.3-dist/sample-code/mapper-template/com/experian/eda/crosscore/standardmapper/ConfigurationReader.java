package com.experian.eda.crosscore.standardmapper;

import java.util.Map;

/**
 * This {@code ConfigurationReader} interface declares the {@code readConfiguration} method.
 * <p>
 * That method is used for coverting key-value properties (<i>that represent a mapper
 * configuration</i>) to a concrete mapper configuration class of type {@code Configuration}
 * class.
 */
public interface ConfigurationReader<Configuration> extends AutoCloseable {

  /**
   * This {@code readConfiguration} method converts raw mapper configuration to concrete mapper configuration
   * class {@code Configuration}.
   *
   * @param configuration the map representation of configuration
   * @return the configuration object of type Configuration
   */
  Configuration readConfiguration(Map<String, Object> configuration);
}
