package com.experian.eda.crosscore.api.request.payload;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class representing the result of a Rule in an External Result of a CrossCore message.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Rule {

  private String rule;
  private String value;

}
