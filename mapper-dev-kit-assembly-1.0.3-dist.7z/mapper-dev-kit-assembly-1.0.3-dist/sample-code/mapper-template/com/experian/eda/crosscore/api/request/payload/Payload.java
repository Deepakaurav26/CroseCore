package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.request.payload.contact.Contact;
import com.experian.eda.crosscore.api.validation.NotNullElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import javax.validation.Valid;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class Payload {

  @Valid
  private List<@NotNullElement ControlOption> control;
  private String source;
  @Valid
  private List<@NotNullElement Contact> contacts;
  @Valid
  private List<@NotNullElement FinancialAccount> financialAccounts;
  @Valid
  private List<@NotNullElement Contract> contracts;
  @Valid
  private List<@NotNullElement Vehicle> vehicles;
  @Valid
  private Application application;
  @Valid
  private Device device;
  @Valid
  private UserAccount userAccount;
  @Valid
  private LoyaltyProgram loyaltyProgram;
  private Session session;
  @Valid
  private List<@NotNullElement Transaction> transactions;
  @Valid
  private List<@NotNullElement Order> orders;
  @Valid
  private List<@NotNullElement ExternalResult> externalResults;
  @Valid
  private List<@NotNullElement ExternalLookup> externalLookups;
  @Valid
  private List<@NotNullElement UserDefinedField> userDefinedFields;
  @Valid
  private List<@NotNullElement DecisionElementsWithServiceName> decisionElements;
  private KnowledgeBasedAuthentication kba;

  public static class Source {

    public static final String WEB = "WEB";
    public static final String FAX = "FAX";
    public static final String KIOSK = "KIOSK";
    public static final String MOBILE = "MOBILE";
    public static final String PHONE = "PHONE";
    public static final String UNKNOWN = "UNKNOWN";
    public static final String POSTAL = "POSTAL";
    public static final String BRANCH = "BRANCH";
    public static final String DIRECT = "DIRECT";
  }
}
