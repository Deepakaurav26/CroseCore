package com.experian.eda.crosscore.api.request.payload.contact;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Telephone {

  private String id;
  private String number;
  private String type;
  private String areaCode;
  private String internationalCode;
  private String provider;
  private String phoneIdentifier;
  private String stdCode;
  private String extension;

  public static class Type {

    private Type() {}

    public static final String FAX = "FAX";
    public static final String IP = "IP";
    public static final String LANDLINE = "LANDLINE";
    public static final String MOBILE = "MOBILE";
    public static final String OTHER = "OTHER";
    public static final String SATELLITE = "SATELLITE";
  }

  public static class PhoneIdentifier {

    private PhoneIdentifier() {}

    public static final String BUS = "BUS";
    public static final String DAY = "DAY";
    public static final String EVE = "EVE";
    public static final String FAX = "FAX";
    public static final String HOME = "HOME";
    public static final String MOBILE = "MOBILE";
    public static final String OTH = "OTH";
    public static final String WORK = "WORK";
  }

  public static class StdCode {

    private StdCode() {}

    public static final String N = "N";
    public static final String Q = "Q";
    public static final String X = "X";
  }
}
