package com.experian.eda.crosscore.api.request.payload.contact;

import com.experian.eda.crosscore.api.DateFormats;
import com.experian.eda.crosscore.api.validation.NotNullElement;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.DateTime;

import java.util.List;
import javax.validation.Valid;

/**
 * Class representing an Employment History JSON object in a CrossCore message.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class EmploymentHistory {

  private String id;
  private String employerName;
  private Address employerAddress;
  @Valid
  private List<@NotNullElement Telephone> employerTelephones;
  private String employmentType;
  private String employmentStatus;
  private TimeSpan timeWithEmployer;
  private String occupationType;
  @Valid
  private List<@NotNullElement Income> incomes;
  private String empContactName;
  private String empEmail;
  @JsonFormat(pattern = DateFormats.DAY)
  private DateTime empStartDate; //todo: validate date format
  @JsonFormat(pattern = DateFormats.DAY)
  private DateTime empEndDate; //todo: validate date format
  private String employeeNumber;
  private String jobType;
  private String typeOfOrganization;
  private String employerRegistrationNumber;
  private String employerIndustry;
  private String jobTitle;

  public static class EmploymentType {

    private EmploymentType() {}

    public static final String CURRENT = "CURRENT";
    public static final String PREVIOUS = "PREVIOUS";
  }

  public static class EmploymentStatus {

    private EmploymentStatus() {}

    public static final String EMPLOYED = "EMPLOYED";
    public static final String FULL_TIME = "FULL_TIME";
    public static final String GENERAL = "GENERAL";
    public static final String HOMEMAKER = "HOMEMAKER";
    public static final String HOUSEWIFE = "HOUSEWIFE";
    public static final String HUF = "HUF";
    public static final String MEMBER_DIRECTOR = "MEMBER_DIRECTOR";
    public static final String NRI = "NRI";
    public static final String OTHER = "OTHER";
    public static final String PART_TIME = "PART_TIME";
    public static final String RETIRED = "RETIRED";
    public static final String SELF_EMPLOYED = "SELF_EMPLOYED";
    public static final String SELF_EMPLOYED_NON_PROFESSIONAL = "SELF_EMPLOYED_NON_PROFESSIONAL";
    public static final String SELF_EMPLOYED_PROFESSIONAL = "SELF_EMPLOYED_PROFESSIONAL";
    public static final String SOLE_OWNER = "SOLE_OWNER";
    public static final String STUDENT = "STUDENT";
    public static final String SURROGATE = "SURROGATE";
    public static final String UNEMPLOYED = "UNEMPLOYED";
  }

  public static class OccupationType {

    private OccupationType() {}

    public static final String CLERICAL = "CLERICAL";
    public static final String CREATIVE = "CREATIVE";
    public static final String DIRECTOR = "DIRECTOR";
    public static final String DRIVER = "DRIVER";
    public static final String HOUSEWIFE = "HOUSEWIFE";
    public static final String JUNIOR = "JUNIOR";
    public static final String LABOURER = "LABOURER";
    public static final String LEGAL = "LEGAL";
    public static final String MANAGER = "MANAGER";
    public static final String MEDICAL = "MEDICAL";
    public static final String MILITARY = "MILITARY";
    public static final String OFFICE = "OFFICE";
    public static final String OTHER = "OTHER";
    public static final String OWNER = "OWNER";
    public static final String PROFESSIONAL = "PROFESSIONAL";
    public static final String PUBLIC_SECTOR = "PUBLIC_SECTOR";
    public static final String RETIRED = "RETIRED";
    public static final String SALES = "SALES";
    public static final String SELF_EMPLOYED = "SELF_EMPLOYED";
    public static final String SEMI_PROFESSIONAL = "SEMI_PROFESSIONAL";
    public static final String SEMI_SKILLED = "SEMI_SKILLED";
    public static final String SERVICE = "SERVICE";
    public static final String SKILLED_WORKER = "SKILLED_WORKER";
    public static final String SOCIAL_WORKER = "SOCIAL_WORKER";
    public static final String SPORTS = "SPORTS";
    public static final String STUDENT = "STUDENT";
    public static final String SUPERVISOR = "SUPERVISOR";
    public static final String TRADE = "TRADE";
    public static final String UKNNOWN = "UKNNOWN";
    public static final String UNEMPLOYED = "UNEMPLOYED";
    public static final String UNSKILLED = "UNSKILLED";
  }

  public static class JobType {

    private JobType() {}

    public static final String CLERICAL = "CLERICAL";
    public static final String CREATIVE = "CREATIVE";
    public static final String DIRECTOR = "DIRECTOR";
    public static final String DRIVER = "DRIVER";
    public static final String HOUSEWIFE = "HOUSEWIFE";
    public static final String JUNIOR = "JUNIOR";
    public static final String LABOURER = "LABOURER";
    public static final String LEGAL = "LEGAL";
    public static final String MANAGER = "MANAGER";
    public static final String MEDICAL = "MEDICAL";
    public static final String MILITARY = "MILITARY";
    public static final String OFFICE = "OFFICE";
    public static final String OTHER = "OTHER";
    public static final String OWNER = "OWNER";
    public static final String PROFESSIONAL = "PROFESSIONAL";
    public static final String PUBLIC_SECTOR = "PUBLIC_SECTOR";
    public static final String RETIRED = "RETIRED";
    public static final String SALES = "SALES";
    public static final String SELF_EMPLOYED = "SELF_EMPLOYED";
    public static final String SEMI_PROFESSIONAL = "SEMI_PROFESSIONAL";
    public static final String SEMI_SKILLED = "SEMI_SKILLED";
    public static final String SERVICE = "SERVICE";
    public static final String SKILLED_WORKER = "SKILLED_WORKER";
    public static final String SOCIAL_WORKER = "SOCIAL_WORKER";
    public static final String SPORTS = "SPORTS";
    public static final String STUDENT = "STUDENT";
    public static final String SUPERVISOR = "SUPERVISOR";
    public static final String TRADE = "TRADE";
    public static final String UKNNOWN = "UKNNOWN";
    public static final String UNEMPLOYED = "UNEMPLOYED";
    public static final String UNSKILLED = "UNSKILLED";
  }
}
