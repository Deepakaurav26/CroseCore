package com.experian.eda.crosscore.api.response.responseHeader;

import com.experian.eda.crosscore.api.DateFormats;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.DateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ResponseHeader {

  public static class ResponseType {

    public static final String ERROR = "ERROR";
    public static final String WARNING = "WARNING";
    public static final String INFO = "INFO";
  }

  @JsonProperty("tenantID")
  private String tenantId;
  private String requestType;
  private String clientReferenceId;
  private String expRequestId;
  @JsonFormat(pattern = DateFormats.SECOND)
  @JsonDeserialize(converter = ResponseMessageTimeConverter.class) // TODO: remove after we upgrade every environment to 1.1
  private DateTime messageTime;
  private OverallResponse overallResponse;
  private String responseCode;
  private String responseType;
  private String responseMessage;

}
