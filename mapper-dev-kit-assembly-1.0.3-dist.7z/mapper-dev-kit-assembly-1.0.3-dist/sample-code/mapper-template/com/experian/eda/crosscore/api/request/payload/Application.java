package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.DateFormats;
import com.experian.eda.crosscore.api.validation.NotNullElement;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.DateTime;

import java.util.List;
import javax.validation.Valid;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Application {

  @JsonFormat(pattern = DateFormats.SECOND)
  private DateTime originalRequestTime;
  private String type;
  private Long durationInMillis;
  private String status;
  private Boolean notificationRequired;
  private String brand;
  private String sourceOfIntroduction;
  @Valid
  @JsonProperty(value = "financialAccountIds")
  private List<@NotNullElement FinancialAccount> financialAccounts;
  @Valid
  @JsonProperty(value = "contractIds")
  private List<@NotNullElement Contract> contracts;
  private ProductDetails productDetails;
  @Valid
  private PolicyDetails policyDetails;
  @Valid
  private ClaimDetails claimDetails;
  @Valid
  private List<@NotNullElement Applicant> applicants;
  @Valid
  private List<@NotNullElement ApplicationEntity> applicationEntities;
  private String memo;
  private String oneTimePasscode;
  @JsonFormat(pattern = DateFormats.DAY)
  private DateTime messageTime;
  private String expReference;
  private String aps;
  private String apsUserId;
  private String operatorId;
  private String operatorName;
  private String creditProtection;
  private String branchName;

  public static class ApplicationType {

    private ApplicationType() {}

    public static final String BANK = "BANK";
    public static final String LOAN = "LOAN";
    public static final String CREDIT = "CREDIT";
    public static final String OTHER = "OTHER";
    public static final String EXTERNAL = "EXTERNAL";
    public static final String TELCO_CONTRACT = "TELCO_CONTRACT";
    public static final String INVESTMENT = "INVESTMENT";
    public static final String SAVINGS = "SAVINGS";
    public static final String ISA = "ISA";
    public static final String SHARE = "SHARE";
    public static final String MORTGAGE = "MORTGAGE";
    public static final String CREDITCARD = "CREDITCARD";
    public static final String INSURANCE_CLAIM = "INSURANCE_CLAIM";
    public static final String INSURANCE_POLICY = "INSURANCE_POLICY";
  }

  public static class Status {

    private Status() {}

    public static final String ACCEPTED = "ACCEPTED";
    public static final String CANCELLED = "CANCELLED";
    public static final String CONFIRMATION = "CONFIRMATION";
    public static final String DECLINED = "DECLINED";
    public static final String ERROR = "ERROR";
    public static final String EXCEPTION = "EXCEPTION";
    public static final String PENDING = "PENDING";
    public static final String REFERRED = "REFERRED";
    public static final String UNKNOWN = "UNKNOWN";
    public static final String WITHDRAWN = "WITHDRAWN";
  }
}
