package com.experian.eda.crosscore.api.request.payload.contact;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonUnwrapped;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class representing an Income JSON object in a CrossCore message.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Income {

  private String id;
  private String typeOfIncome;
  private String profitIndicator;
  private String source;
  private String frequency;
  @JsonUnwrapped
  private MonetaryAmount monetaryAmount;

  public static class TypeOfIncome {

    private TypeOfIncome() {}

    public static final String GROSS = "GROSS";
    public static final String NET = "NET";
    public static final String OTHER_GROSS = "OTHER_GROSS";
    public static final String TOTAL_GROSS = "TOTAL_GROSS";
  }

  public static class Source {

    private Source() {}

    public static final String BENEFITS = "BENEFITS";
    public static final String COMPENSATION = "COMPENSATION";
    public static final String DIVIDEND = "DIVIDEND";
    public static final String EMPLOYMENT = "EMPLOYMENT";
    public static final String GIFTS = "GIFTS";
    public static final String INHERITANCE = "INHERITANCE";
    public static final String INSURANCE_PAYOUT = "INSURANCE_PAYOUT";
    public static final String INVESTMENTS = "INVESTMENTS";
    public static final String PENSION = "PENSION";
    public static final String PROPERTY_RENTAL = "PROPERTY_RENTAL";
    public static final String PROPERTY_SALE = "PROPERTY_SALE";
    public static final String REVENUE = "REVENUE";
    public static final String SAVINGS = "SAVINGS";
    public static final String SECONDARY_EMPLOYMENT = "SECONDARY_EMPLOYMENT";
    public static final String SELF_EMPLOYED = "SELF_EMPLOYED";
    public static final String TAX_REBATE = "TAX_REBATE";
  }

  private static class Frequency {

    private Frequency() {}

    public static final String HOURLY = "HOURLY";
    public static final String DAILY = "DAILY";
    public static final String WEEKLY = "WEEKLY";
    public static final String BIWEEKLY = "BIWEEKLY";
    public static final String MONTHLY = "MONTHLY";
    public static final String SEMI_MONTHLY = "SEMI_MONTHLY";
    public static final String YEARLY = "YEARLY";
    public static final String QUATERLY = "QUATERLY";
    public static final String SEMI_ANNUALLY = "SEMI_ANNUALLY";
    public static final String ANNUALLY = "ANNUALLY";
  }
}
