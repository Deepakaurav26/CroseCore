package com.experian.eda.crosscore.standardmapper;

import com.experian.eda.crosscore.json.DefaultValidator;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import lombok.val;

import java.util.Map;

/**
 * This {@code PojoConfigurationReader} class converts raw key-value pairs to mapper configuration
 * of type {@code <Configuration>}, runs a validation check on it, and returns the same.
 */
@Slf4j
@AllArgsConstructor
public class PojoConfigurationReader<Configuration> implements ConfigurationReader<Configuration> {

  /*
   * Instance of ObjectMapper that is used to convert Map representation of Mapper configuration to
   * <Configuration> class type.
   */
  private final ObjectMapper objectMapper = new ObjectMapper();
  /*
   * Class type that the raw configuration will be converted to by the objectMapper
   */
  @NonNull
  private final Class<? extends Configuration> configurationClass;

  /**
   * This {@code readConfiguration} method uses {@link com.fasterxml.jackson.databind.ObjectMapper} to convert a raw configuration map
   * to {@link #configurationClass} and run a validation check on it.
   *
   * @param configuration the map representation of mapper configuration class
   * @return the converted value of {@literal <Configuration>} class type
   * @throws java.lang.RuntimeException if objectMapper fails to convert
   * @throws ValidationException if the validation check fails on the converted configuration object
   */
  @Override
  public Configuration readConfiguration(@NonNull final Map<String, Object> configuration) {
    val readConfig = objectMapper.convertValue(configuration, configurationClass);
    DefaultValidator.throwIfInvalid(readConfig, "mapper configuration");
    return readConfig;
  }
  /**
   * Calls {@link #close()} for all the closeable classes after the end of the call.
   *
   * @return void
   * @throws java.lang.Exception if there is a failure to close
   */
  @Override
  public void close() throws Exception {
    // do nothing
  }
}
