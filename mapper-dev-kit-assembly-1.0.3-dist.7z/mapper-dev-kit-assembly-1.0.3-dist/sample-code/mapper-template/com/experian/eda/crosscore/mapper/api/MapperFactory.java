package com.experian.eda.crosscore.mapper.api;

/**
 * The entry point of a mapper, that creates the {@link Mapper} instance.
 * Every mapper must contain exactly one class that implements this interface.
 *
 * @param <T> The mapper class that will be created
 */
public interface MapperFactory<T extends Mapper> {

  /**
   * Create a mapper.
   * The Mapper Service will call this method once upon startup, so you should do any expensive initialization here.
   *
   * @param services Services available to a mapper.
   *
   * @return An instance of a {@link Mapper}
   */
  T createMapper(Services services);

  /**
   * Get the static information about this mapper for service discovery. Called upon startup when the Mapper Service
   * registers itself for service discovery.
   *
   * @return MapperInformation
   */
  MapperInformation getMapperInformation();

}
