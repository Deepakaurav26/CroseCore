package com.experian.eda.crosscore.standardmapper.validation;

import com.experian.eda.crosscore.standardmapper.RetryingTransporterConfiguration;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * This is a class that performs validation constraints check on
 * {@link com.experian.eda.crosscore.standardmapper.RetryingTransporterConfiguration}
 */
public class RetryConfigValidator implements ConstraintValidator<RetryConfig, RetryingTransporterConfiguration> {

  @Override
  public void initialize(final RetryConfig constraintAnnotation) {
  //do nothing
  }

  /**
   *
   * @param value An instance of {@link RetryingTransporterConfiguration} that needs to be validated
   * @param context is not being used in this instance
   * @return The boolean value result of the validation performed
   */
  @Override
  public boolean isValid(final RetryingTransporterConfiguration value, final ConstraintValidatorContext context) {
    return value.getBaseDelayMillis() < value.getMaxDelayMillis();
  }
}
