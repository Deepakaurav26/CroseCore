package com.experian.eda.crosscore.api.request.payload;

import java.util.List;

import com.experian.eda.crosscore.api.validation.NotNullElement;
import org.joda.time.DateTime;

import com.experian.eda.crosscore.api.DateFormats;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Device {

  private String id;
  private String ipAddress;
  @Valid
  private List<@NotNullElement Header> headers;
  @Valid
  private List<@NotNullElement UserIdentityCookie> userIdentityCookies;
  private String jsc;
  private Hdim hdim;
  @JsonFormat(pattern = DateFormats.MILLISECOND)
  private DateTime serverTime;
  private String deviceLocation;
}
