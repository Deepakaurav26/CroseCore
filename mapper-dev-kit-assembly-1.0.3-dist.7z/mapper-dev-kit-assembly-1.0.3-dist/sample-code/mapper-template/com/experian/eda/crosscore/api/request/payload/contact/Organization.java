package com.experian.eda.crosscore.api.request.payload.contact;

import com.experian.eda.crosscore.api.DateFormats;
import com.experian.eda.crosscore.api.validation.NotNullElement;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.DateTime;

import java.util.List;
import javax.validation.Valid;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Organization {

  private String id;
  private String typeOfOrganization;
  private String orgName;
  private String companyType;
  private String companyRegistrationNumber;
  @Valid
  private List<@NotNullElement ContactName> contactNames;
  @JsonProperty(value = "directorContactIds")
  @Valid
  private Contact contact; // todo: follow up with MF on this
  @Valid
  private List<@NotNullElement NetProfitYear> netProfitYear;
  private String dxNumber;
  private String status;
  private String miscReference;
  private String taxNumber;
  private String tradingAsName;
  @JsonFormat(pattern = DateFormats.DAY)
  private DateTime registrationDate;
  private TimeSpan tradingPeriod;
  private Integer numberOfEmployees;
  private String legalStatus;
  private MonetaryAmount forecastedTurnover;

  public static class TypeOfOrganization {

    private TypeOfOrganization() {}

    public final static String ADMINISTRATION = "ADMINISTRATION";
    public final static String AGRICULTURE = "AGRICULTURE";
    public final static String ARMED_FORCES = "ARMED_FORCES";
    public final static String BANK = "BANK";
    public final static String BUSINESS = "BUSINESS";
    public final static String CONSTRUCTION = "CONSTRUCTION";
    public final static String DESIGN = "DESIGN";
    public final static String EDUCATION = "EDUCATION";
    public final static String ENGINEERING = "ENGINEERING";
    public final static String ENTERTAINMENT = "ENTERTAINMENT";
    public final static String EXCISE = "EXCISE";
    public final static String FINANCIAL_SERVICES = "FINANCIAL_SERVICES";
    public final static String FOOD = "FOOD";
    public final static String GEMS_AND_JEWELLERY = "GEMS_AND_JEWELLERY";
    public final static String GOVERNMENT_SERVICES = "GOVERNMENT_SERVICES";
    public final static String HEALTHCARE = "HEALTHCARE";
    public final static String HOSPITALITY_AND_TOURISM = "HOSPITALITY_AND_TOURISM";
    public final static String HOUSE_WIFE = "HOUSE_WIFE";
    public final static String INDUSTRIAL = "INDUSTRIAL";
    public final static String INFORMATION_TECHNOLOGY = "INFORMATION_TECHNOLOGY";
    public final static String INSTITUTION = "INSTITUTION";
    public final static String INSURER = "INSURER";
    public final static String LEGAL_SERVICES = "LEGAL_SERVICES";
    public final static String MANAFACTURING = "MANAFACTURING";
    public final static String MEDIA_AND_ADVERTISING = "MEDIA_AND_ADVERTISING";
    public final static String NATURAL_RESOURCES = "NATURAL_RESOURCES";
    public final static String OTHER = "OTHER";
    public final static String PACKAGING = "PACKAGING";
    public final static String REAL_ESTATE = "REAL_ESTATE";
    public final static String RETAIL = "RETAIL";
    public final static String SALES = "SALES";
    public final static String SCIENCE = "SCIENCE";
    public final static String SERVICES = "SERVICES";
    public final static String SKILLED_CRAFTS = "SKILLED_CRAFTS";
    public final static String SOLICITOR = "SOLICITOR";
    public final static String SPORTS_AND_LEISURE = "SPORTS_AND_LEISURE";
    public final static String SUPPLY = "SUPPLY";
    public final static String TELECOMMUNICATIONS = "TELECOMMUNICATIONS";
    public final static String TEXTILES = "TEXTILES";
    public final static String TRADING = "TRADING";
    public final static String TRANSPORT_AND_LOGISTICS = "TRANSPORT_AND_LOGISTICS";
    public final static String TRAVEL = "TRAVEL";
  }

  public static class CompanyType {

    private CompanyType() {}

    public final static String C = "C";
    public final static String F = "F";
    public final static String G = "G";
    public final static String L = "L";
    public final static String LLP = "LLP";
    public final static String LP = "LP";
    public final static String N = "N";
    public final static String O = "O";
    public final static String P = "P";
    public final static String S = "S";
    public final static String T = "T";
    public final static String UA = "UA";
    public final static String UC = "UC";
    public final static String SOLICITOR = "SOLICITOR";
  }
}
