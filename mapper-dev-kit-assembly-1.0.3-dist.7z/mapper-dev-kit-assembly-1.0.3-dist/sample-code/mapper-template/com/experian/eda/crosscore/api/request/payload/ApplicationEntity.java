package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.request.payload.contact.Contact;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;

/**
 * Class representing the ApplicationEntity JSON object in a CrossCore message.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ApplicationEntity {

  private String entityType;
  @JsonProperty(value = "contactId")
  @Valid
  private Contact contact;
  private Boolean approvedSupplier;
  private String roleInAccident;
  @JsonProperty(value = "vehicleId")
  private Vehicle vehicle;

  public static class EntityType {

    private EntityType() {}

    public static final String ACCIDENT_MANAGEMENT = "ACCIDENT_MANAGEMENT";
    public static final String ACCOUNTANT = "ACCOUNTANT";
    public static final String APPLYING_ORG = "APPLYING_ORG";
    public static final String ASSET = "ASSET";
    public static final String BENEFICIARY = "BENEFICIARY";
    public static final String BRANCH = "BRANCH";
    public static final String BROKER = "BROKER";
    public static final String DEALER_ORGANIZATION = "DEALER_ORGANIZATION";
    public static final String DESTINATION_ACCOUNT = "DESTINATION_ACCOUNT";
    public static final String ESTATE_AGENT = "ESTATE_AGENT";
    public static final String GUARANTOR_ORGANIZATION = "GUARANTOR_ORGANIZATION";
    public static final String INJURED_PARTY = "INJURED_PARTY";
    public static final String LANDLORD = "LANDLORD";
    public static final String LENDER = "LENDER";
    public static final String REFERENCE = "REFERENCE";
    public static final String RELATIVE = "RELATIVE";
    public static final String SALES_AGENT = "SALES_AGENT";
    public static final String SECURITY_ADDRESS = "SECURITY_ADDRESS";
    public static final String SOLICITOR = "SOLICITOR";
    public static final String SURVEYOR = "SURVEYOR";
    public static final String TENANT = "TENANT";
    public static final String THIRD_PARTY = "THIRD_PARTY";
    public static final String THIRD_PARTY_EXPERT = "3RD_PARTY_EXPERT";
    public static final String THIRD_PARTY_ORG = "3RD_PARTY_ORG";
    public static final String TRUSTEE = "TRUSTEE";
    public static final String VALUER = "VALUER";
    public static final String VENDOR = "VENDOR";
    public static final String WITNESS = "WITNESS";
  }

  public static class RoleInAccident {

    private RoleInAccident() {}

    public static final String CLAIMANT = "CLAIMANT";
    public static final String CYCLIST = "CYCLIST";
    public static final String DRIVER = "DRIVER";
    public static final String DRIVER_NOT_KNOWN = "DRIVER_NOT_KNOWN";
    public static final String OTHER = "OTHER";
    public static final String OTHER_INJURED_PERSON = "OTHER_INJURED_PERSON";
    public static final String OWNER = "OWNER";
    public static final String PASSENGER_INSURED_VEHICLE = "PASSENGER_INSURED_VEHICLE";
    public static final String PASSENGER_OTHER_VEHICLE = "PASSENGER_OTHER_VEHICLE";
    public static final String PEDESTRIAN = "PEDESTRIAN";
    public static final String POLICYHOLDER = "POLICYHOLDER";
    public static final String POLICYHOLDER_CLAIMANT = "POLICYHOLDER_CLAIMANT";
    public static final String POLICYHOLDER_DRIVER = "POLICYHOLDER_DRIVER";
    public static final String PREMIUM_PAYER = "PREMIUM_PAYER";
    public static final String RIDER = "RIDER";
    public static final String THIRD_PARTY = "THIRD_PARTY";
  }
}
