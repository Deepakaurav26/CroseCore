package com.experian.eda.crosscore.api.request.payload;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class representing a User Defined Element in the User Defined Fields section of a CrossCore
 * message.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserDefinedElement {

  private String fieldName;
  private String fieldValue;
}
