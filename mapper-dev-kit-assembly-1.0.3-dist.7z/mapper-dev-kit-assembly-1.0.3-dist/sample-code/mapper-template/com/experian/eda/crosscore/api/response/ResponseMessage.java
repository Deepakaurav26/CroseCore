package com.experian.eda.crosscore.api.response;

import com.experian.eda.crosscore.api.request.payload.Payload;
import com.experian.eda.crosscore.api.response.clientResponsePayload.ClientResponsePayload;
import com.experian.eda.crosscore.api.response.responseHeader.ResponseHeader;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ResponseMessage {

  private ResponseHeader responseHeader;
  @Valid
  private Payload originalRequestData;
  @Valid
  private ClientResponsePayload clientResponsePayload;

}
