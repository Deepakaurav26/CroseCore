package com.experian.eda.crosscore.standardmapper.request;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.Request;

/**
 * {@code RequestContainer} is an interface that represents type that is consumed by {@code RestTransporter} and the
 * implementing class must implement {@code getContext} and {@code buildRequest} methods
 * @param <Context> The type of the context object returned by {@link #getContext}.
 */
public interface RequestContainer<Context> {

  /**
   An arbitrary object that will be passed back in the response from the transporter ({@link RestResponseContainer#getContext}).
   Useful if your {@link ResponseGenerator} needs access to data produced by the {@link Transformer} but that's not part of the request sent to the backing application.
   */
  Context getContext();
  Request buildRequest(final ObjectMapper objectMapper) throws JsonProcessingException;
}
