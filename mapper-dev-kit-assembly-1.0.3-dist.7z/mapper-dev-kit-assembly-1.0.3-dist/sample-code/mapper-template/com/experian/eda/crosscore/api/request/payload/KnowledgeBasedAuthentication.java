package com.experian.eda.crosscore.api.request.payload;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class representing the Knowledge Based Authentication (KBA) JSON object in a CrossCore message.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class KnowledgeBasedAuthentication {

  private String riskStrategyNumber;
  private String languageCode;
  private String championChallengerRandomNumber;
  private Boolean outWalletQuestionsRequest;
  @JsonProperty(value = "sessionId")
  private Session session;
  private KbaAnswers answers;
  private KbaUserDefinedNumerics userDefinedNumerics;
  private KbaUserDefinedTexts userDefinedTexts;
  private KbaUserDefinedDates userDefinedDates;
}
