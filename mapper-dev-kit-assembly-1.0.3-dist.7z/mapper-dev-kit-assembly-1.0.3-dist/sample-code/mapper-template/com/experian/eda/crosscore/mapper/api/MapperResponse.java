package com.experian.eda.crosscore.mapper.api;

import com.experian.eda.crosscore.api.decisionElements.DecisionElements;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

import java.util.List;

/**
 * The response of a mapper call, usually produced by the {@link Mapper#call} method.
 */
@Value
@Builder
@AllArgsConstructor
public class MapperResponse {

  /**
   * The decision elements derived from the response from the backing application.
   */
  @NonNull
  List<DecisionElements> decisionElements;

  /**
   * The {@link #decisionElements} converted to a flat list of strings, for use by the strategy.
   * The structure and contents of this object is defined per mapper in the Decision Object Specification document.
   * The size of this list should not exceed 998 elements.
   * The length of each element in the list should not exceed 255 characters.
   */
  @NonNull
  List<String> strategyResponse;
}
