package com.experian.eda.crosscore.standardmapper;

import static com.google.common.base.Preconditions.checkState;

import static java.net.HttpURLConnection.HTTP_INTERNAL_ERROR;

import com.experian.eda.crosscore.mapper.api.exceptions.MapperException;
import com.experian.eda.crosscore.standardmapper.request.RequestContainer;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import okhttp3.Headers;
import okhttp3.OkHttpClient;
import okhttp3.internal.platform.Platform;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * This {@code RestTransporter} class is used when {@link Transporter#transport} must make a rest web service call
 * to the backing application.
 * <p>
 * This class uses instance of {@code OkHttpClient} to make the rest call.
 */
@Slf4j
@AllArgsConstructor
public class RestTransporter<RequestType extends RequestContainer<Context>, ResponseType, Context, Configuration extends RestTransporterConfigurationProvider>
    implements Transporter<RequestType, RestResponseContainer<ResponseType, Context>, Configuration> {

  /*
   * Instance of ObjectMapper that converts the Reqeust body of type <RequestType>
   * to byte[] when an OkHttp Request is built.
   */
  @NonNull
  private final ObjectMapper objectMapper;
  /*
   * Class type that the httpClient response will be converted to
   */
  @NonNull
  private final Class<? extends ResponseType> transporterResultClass;
  /*
   * OkHttpClient instance that is used to call the backing app.
   * This is further configured based on configuration values that are passed in as nested
   * RestTransporterConfiguration objects like timeout values and sslSocketFactory.
   */
  @NonNull
  private final OkHttpClient okHttpClient;

  public RestTransporter(final ObjectMapper objectMapper, final Class<? extends ResponseType> transporterResultClass) {
    this(objectMapper, transporterResultClass, new OkHttpClient.Builder().build());
  }

  /**
   * This {@code transport} method uses {@code httpClient} to make rest web service call to the backing app.
   *
   * @param transformerResult the value of type {@literal <RequestType>} that extends RequestContainer.
   *                          This is a result of Transformer#transformRequest.
   *                          At this point this should have gone through all mapping and conversion
   *                          that was necessary to be passed on to the {@link Transporter}.
   *                          Reference the process in {@link StandardMapper#call}.
   * @param config the mapper configuration of type  {@literal <Configuration>}
   * @return the RestResponseContainer which contains the OkHttp okhttp3.Response, headers, and context object.
   *         Each is meta information passed from RequestContainer to RestResponseContainer.
   * @throws NullPointerException if either transformerResult or config is null
   * @throws RetriableMapperException if httpClient response code is >=500 or {@link IOException} is caught
   *                                  by httpClient call
   * @throws IllegalStateException if httpClient response is not successful
   * @throws MapperException if the httpClient response body is null
   */
  @Override
  public RestResponseContainer<ResponseType, Context> transport(final RequestType transformerResult,
                                                                final Configuration config) throws MapperException {

    Objects.requireNonNull(transformerResult);
    Objects.requireNonNull(config);

    try {
      val newOkHttpClientBuilder = this.okHttpClient.newBuilder();
      if (config.getRestTransporter().getSslSocketFactory() != null) {
        newOkHttpClientBuilder.sslSocketFactory(config.getRestTransporter().getSslSocketFactory(),
                                                Platform.get().trustManager(config.getRestTransporter()
                                                                                  .getSslSocketFactory()));
      }
      newOkHttpClientBuilder.readTimeout(config.getRestTransporter().getReadTimeoutMillis(), TimeUnit.MILLISECONDS)
                            .writeTimeout(config.getRestTransporter().getWriteTimeoutMillis(), TimeUnit.MILLISECONDS)
                            .connectTimeout(config.getRestTransporter().getConnectTimeoutMillis(),
                                            TimeUnit.MILLISECONDS);
      OkHttpClient enhancedOkHttpClient = newOkHttpClientBuilder.build();

      val req = transformerResult.buildRequest(objectMapper);
      val res = enhancedOkHttpClient.newCall(req).execute();
      final byte[] bodyBytes;
      if (res.body() != null) {
        bodyBytes = res.body().bytes();
        log.trace("Raw response: {}", new String(bodyBytes, StandardCharsets.UTF_8));
      } else {
        bodyBytes = null;
      }
      if (res.code() >= HTTP_INTERNAL_ERROR) {
        throw new RetriableMapperException("Retriable Server Error. Response Code: " + res.code()
                                           + ", Response Message: " + res.message());
      }
      checkState(res.isSuccessful(), "Non-Retriable Server Error. Response Code: " + res.code()
                                     + ", Response Message: " + res.message());
      if (bodyBytes == null) {
        throw new MapperException("Empty Response");
      }

      return RestResponseContainer
          .<ResponseType, Context>builder()
          .body(objectMapper.readValue(bodyBytes, transporterResultClass))
          .headers(makeHeaders(res.headers()))
          .context(transformerResult.getContext())
          .build();

    } catch (IOException e) {
      val errorMessage = "Failed to call backing application: " + e.getMessage();
      log.debug(errorMessage, e);
      throw new RetriableMapperException(errorMessage);
    }
  }

  /**
   *
   * @param headers HttpClient response header
   * @return Converted {@code headers} to a Map representation
   */
  private Map<String, List<String>> makeHeaders(Headers headers) {
    Map<String, List<String>> headerMap = new HashMap<>();
    for (int i = 0; i < headers.size(); i++) {
      headerMap.put(headers.name(i), headers.values(headers.name(i)));
    }
    return headerMap;
  }

  /**
   * Calls {@link #close()} for all the closeable classes after the end of the call.
   *
   * @return void
   * @throws java.lang.Exception if there is a failure to close
   */
  @Override
  public void close() throws Exception {
  }
}
