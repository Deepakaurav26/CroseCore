package com.experian.eda.crosscore.api.request.payload.contact;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class representing a simple name in a CrossCore message.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ContactName {

  private String firstName;
  private String middleNames;
  private String initials;
  private String surName;
}
