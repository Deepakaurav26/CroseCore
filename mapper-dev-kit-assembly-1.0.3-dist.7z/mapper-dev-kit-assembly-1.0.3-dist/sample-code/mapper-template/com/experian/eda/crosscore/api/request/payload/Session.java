package com.experian.eda.crosscore.api.request.payload;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class representing the Applicant JSON object in a CrossCore message.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Session {

  private String id;
  private String sessionId;
  private Long durationInMillis;
  private Boolean loggedIn;
  private Integer failedLoginAttempts;
  private Boolean multiFactorAuthenticated;
  private Integer challengeAttempts;
  private String thirdPartySessionId;
  private String activityPageCode;
  private Boolean itemsRemoved;
}
