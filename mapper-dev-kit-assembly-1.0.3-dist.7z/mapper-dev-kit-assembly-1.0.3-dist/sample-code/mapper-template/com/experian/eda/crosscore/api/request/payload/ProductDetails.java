package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.DateFormats;
import com.experian.eda.crosscore.api.request.payload.contact.MonetaryAmount;
import com.experian.eda.crosscore.api.request.payload.contact.TimeSpan;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.DateTime;

import java.math.BigDecimal;

/**
 * Class representing the ProductDetails JSON object in a CrossCore message.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProductDetails {

  private String productType;
  private MonetaryAmount productAmount;
  private MonetaryAmount depositAmount;
  private MonetaryAmount abbreviatedAmount;
  private BigDecimal interestRate;
  @JsonFormat(pattern = DateFormats.DAY)
  private DateTime maturityDate;
  private TimeSpan lendingTerm;
  private String purposeOfLoan;
  private BigDecimal ltv;
  private String productCode;
  @JsonProperty(value = "loanReferenceNo")
  private String loanReference;
  private MonetaryAmount assetValue;
  private MonetaryAmount originalAssetValue;
  private String productSubchannel;

  public static class ProductType {

    private ProductType() {}

    public static final String BANK = "BANK";
    public static final String BUILDINGS = "BUILDINGS";
    public static final String BUSINESS = "BUSINESS";
    public static final String CONTENTS = "CONTENTS";
    public static final String CREDIT = "CREDIT";
    public static final String CREDITCARD = "CREDITCARD";
    public static final String EXTERNAL = "EXTERNAL";
    public static final String INVESTMENT = "INVESTMENT";
    public static final String ISA = "ISA";
    public static final String LIFE = "LIFE";
    public static final String LOAN = "LOAN";
    public static final String MORTGAGE = "MORTGAGE";
    public static final String OTHER = "OTHER";
    public static final String PENSION = "PENSION";
    public static final String PET = "PET";
    public static final String PURCHASE = "PURCHASE";
    public static final String SAVINGS = "SAVINGS";
    public static final String SHARE = "SHARE";
    public static final String TELCO_CONTRACT = "TELCO_CONTRACT";
    public static final String TRAVEL = "TRAVEL";
    public static final String VEHICLE = "VEHICLE";
    public static final String WRITTEN_INSTRUCTIONS = "WRITTEN_INSTRUCTIONS";
  }
}
