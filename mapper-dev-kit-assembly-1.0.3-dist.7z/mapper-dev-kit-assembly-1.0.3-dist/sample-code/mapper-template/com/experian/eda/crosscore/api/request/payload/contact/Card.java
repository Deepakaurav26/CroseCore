package com.experian.eda.crosscore.api.request.payload.contact;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class representing the Card JSON object in a CrossCore message.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Card {

  private String id;
  private String type;
  private String brand;
  private String cardHolderName;
  @JsonProperty(value = "cardBillingAddressId")
  private Address address;
  private String cardBinNumber;
  private String cardIssuer;
  private String hashedCardNumber;
  private String tokenisedCardNumber;
  private String clearCardNumber;

  /**
   * Card Expiry date.
   * In the format `MM/YY`.
   */
  // TODO: validate that it's in the correct format
  private String expireDate;

  /**
   * Card Start date.
   * In the format `MM/YY`.
   */
  // TODO: validate that it's in the correct format
  private String startDate;
  private String cardLast4Digits;
  private Integer issueNumber;
  private String securityCode;

  public static class Type {

    private Type() {}

    public static final String CREDIT = "CREDIT";
    public static final String DEBIT = "DEBIT";
  }

  public static class Brand {

    private Brand() {}

    public static final String AMX = "AMX";
    public static final String CUP = "CUP";
    public static final String DIN = "DIN";
    public static final String DSC = "DSC";
    public static final String ELO = "ELO";
    public static final String JCB = "JCB";
    public static final String LSR = "LSR";
    public static final String MST = "MST";
    public static final String MCD = "MCD";
    public static final String SMS = "SMS";
    public static final String VIS = "VIS";
  }
}
