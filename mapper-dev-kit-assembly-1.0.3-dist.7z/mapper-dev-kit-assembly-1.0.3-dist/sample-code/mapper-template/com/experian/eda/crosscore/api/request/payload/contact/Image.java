package com.experian.eda.crosscore.api.request.payload.contact;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Image {

  private String id;
  private String imageData;
  private String faceImage;
  private String fileName;
  private String fileType;
  private String documentPart;
  private String source;

  public static class FileType {

    private FileType() {}

    public static final String JPEG = "JPEG";
    public static final String PNG = "PNG";
    public static final String BMP = "BMP";
    public static final String EXIF = "EXIF";
    public static final String TIFF = "TIFF";
  }

  public static class DocumentPart {

    private DocumentPart() {}

    public static final String FRONT = "FRONT";
    public static final String BACK = "BACK";
    public static final String UNKNOWN = "UNKNOWN";
  }
}
