package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.request.payload.contact.MonetaryAmount;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PetDetails {

  private String name;
  private int age;
  private String gender;
  private String type;
  private Boolean isPedigree;
  private Boolean spayedOrNeutered;
  private String breed;
  private MonetaryAmount purchasePrice;
}

