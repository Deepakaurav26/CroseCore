package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.DateFormats;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.DateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LastActionTimes {

  @JsonFormat(pattern = DateFormats.SECOND)
  private DateTime previousSuccessfulLogin;
  @JsonFormat(pattern = DateFormats.SECOND)
  private DateTime transferThresholdUpdated;
  @JsonFormat(pattern = DateFormats.SECOND)
  private DateTime phoneUpdated;
  @JsonFormat(pattern = DateFormats.SECOND)
  private DateTime addressUpdated;
  @JsonFormat(pattern = DateFormats.SECOND)
  private DateTime emailUpdated;
  @JsonFormat(pattern = DateFormats.SECOND)
  private DateTime updatedViaCallCenter;
  @JsonFormat(pattern = DateFormats.SECOND)
  private DateTime passwordUpdated;
  @JsonFormat(pattern = DateFormats.SECOND)
  private DateTime beneficiaryUpdated;
  @JsonFormat(pattern = DateFormats.SECOND)
  private DateTime payeeUpdated;
  @JsonFormat(pattern = DateFormats.SECOND)
  private DateTime signerUpdated;
  @JsonFormat(pattern = DateFormats.SECOND)
  private DateTime contacted;
}
