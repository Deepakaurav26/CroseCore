package com.experian.eda.crosscore.api.request.payload.contact;

import com.experian.eda.crosscore.api.DateFormats;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.DateTime;

import javax.validation.constraints.Past;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ResidentFrom {

  @Past
  @JsonFormat(pattern = DateFormats.DAY)
  private DateTime fullDateFrom;
  private String yearFrom;
  private String monthFrom;
  private String dayFrom;
}
