package com.experian.eda.crosscore.standardmapper;

import com.experian.eda.crosscore.mapper.api.exceptions.MapperException;

/**
 * This {@code Transporter} interface declares the {@code transport} method and is used by
 * {@link StandardMapper}.
 * <p>
 * The transport operation defines the logic that will communicate with the backing application and handle
 * the response from the backing application.
 *
 * @param <TransformerResult> the class type for the transformed request that gets passed as a transformerResult
 *                            parameter and is a result of {@link Transformer#transformRequest}
 * @param <TransporterResult> the class type for the response that is returned by calling {@link Transporter#transport}
 * @param <Configuration> the class type for {@link MapperConfiguration} and stores value for all the configuration
 *                        related to the mapper.
 *                        This class sometimes implements {@link RetryingTransporterConfiguration} or
 *                        {@link RestTransporterConfiguration} based on the use case.
 */
public interface Transporter<TransformerResult, TransporterResult, Configuration> extends AutoCloseable {

  TransporterResult transport(TransformerResult transformerResult, Configuration config) throws MapperException;
}
