package com.experian.eda.crosscore.standardmapper;

import com.experian.eda.crosscore.mapper.api.MapperResponse;
import com.experian.eda.crosscore.mapper.api.exceptions.MapperException;

/**
 * This {@code ResponseGenerator} interface declares {@code generateResponse} method which is used by
 * {@link StandardMapper}.
 * <p>
 * The {@code generateResponse} operation defines the logic for coverting the response recieved from
 * the backing application and converts it to the CrossCore response of type {@link MapperResponse} with
 * decisions.
 *
 * @param <TransporterResult> the class type for the response that is returned by calling
 *                            {@link Transporter#transport}
 * @param <Configuration> the class type for {@link MapperConfiguration} and stores value for all the
 *                        configuration related to the mapper
 */
public interface ResponseGenerator<TransporterResult, Configuration> extends AutoCloseable {

  MapperResponse generateResponse(TransporterResult transporterResult, Configuration config) throws MapperException;
}
