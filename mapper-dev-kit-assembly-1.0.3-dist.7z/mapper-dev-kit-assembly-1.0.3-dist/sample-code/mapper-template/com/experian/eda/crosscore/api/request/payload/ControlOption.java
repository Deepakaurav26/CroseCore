package com.experian.eda.crosscore.api.request.payload;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ControlOption {

  private String option;
  private String value;

  public static class Option {

    private Option() {}

    public final static String BROKER_NUMBER = "BROKER_NUMBER";
    public final static String CLIENTID = "CLIENTID";
    public final static String CUSTOMERID = "CUSTOMERID";
    public final static String DECISION_CODE = "DECISION_CODE";
    public final static String DETAIL_REQUEST = "DETAIL_REQUEST";
    public final static String DOC_CONTROL = "DOC_CONTROL";
    public final static String END_USER = "END_USER";
    public final static String EVENT_ID = "EVENT_ID";
    public final static String EVENT_TYPE = "EVENT_TYPE";
    public final static String FREEZE_KEY_PIN = "FREEZE_KEY_PIN";
    public final static String ISBIOMETRIC = "ISBIOMETRIC";
    public final static String ISBUREAU = "ISBUREAU";
    public final static String ISDEMOGRAPHIC = "ISDEMOGRAPHIC";
    public final static String ISEMAIL = "ISEMAIL";
    public final static String ISHUNTER = "ISHUNTER";
    public final static String ISMOBILE = "ISMOBILE";
    public final static String ISOTP = "ISOTP";
    public final static String ISPAN = "ISPAN";
    public final static String ISPROVEID = "ISPROVEID";
    public final static String ISVOTERID = "ISVOTERID";
    public final static String MODEL_CODE = "MODEL_CODE";
    public final static String NAMEMATCHSCORE = "NAMEMATCHSCORE";
    public final static String NAMEMATCHVALUE = "NAMEMATCHVALUE";
    public final static String NFD_DETAILED_RESPONSE = "NFD_DETAILED_RESPONSE";
    public final static String NFD_SUBSCRIBER_NUMBER = "NFD_SUBSCRIBER_NUMBER";
    public final static String ORG_CODE = "ORG_CODE";
    public final static String PFAMS = "PFAMS";
    public final static String PFAMV = "PFAMV";
    public final static String PID_PASSSWORD = "PID_PASSSWORD";
    public final static String PID_USERNAME = "PID_USERNAME";
    public final static String PIDXML_VERSION = "PIDXML_VERSION";
    public final static String PRODUCT_OPTION = "PRODUCT_OPTION";
    public final static String PROVEID_PASSWORD = "PROVEID_PASSWORD";
    public final static String PROVEID_USERNAME = "PROVEID_USERNAME";
    public final static String SESSIONTYPE = "SESSIONTYPE";
    public final static String SUBSCRIBER_OPERATOR_INITIAL = "SUBSCRIBER_OPERATOR_INITIAL";
    public final static String SUBSCRIBER_PREAMBLE = "SUBSCRIBER_PREAMBLE";
    public final static String SUBSCRIBER_SUB_CODE = "SUBSCRIBER_SUB_CODE";
    public final static String TARGET_COUNTRY = "TARGET_COUNTRY";
    public final static String TRANSORIGIN = "TRANSORIGIN";
    public final static String USER_EMAIL = "USER_EMAIL";
    public final static String VENDOR = "VENDOR";
    public final static String VENDOR_VERSION = "VENDOR_VERSION";
    public final static String VERBOSE = "VERBOSE";
    public final static String WANTMOBILE = "WANTMOBILE";
    public final static String QUERY = "QUERY";
    public final static String RESOLVE_CLIENTID = "RESOLVE_CLIENTID";
    public final static String PRIVACYTYPE_DNT = "PRIVACYTYPE_DNT";
    public final static String PRIVACYTYPE_IOS = "PRIVACYTYPE_IOS";
    public final static String PRIVACYTYPE_PC = "PRIVACYTYPE_PC";
    public final static String HAS_ANOMALY = "HAS_ANOMALY";
    public final static String WHY_ANOMALY = "WHY_ANOMALY";
  }
}
