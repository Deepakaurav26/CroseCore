package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.request.payload.contact.Contact;
import com.experian.eda.crosscore.api.request.payload.contact.MonetaryAmount;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonUnwrapped;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;

/**
 * Class representing an Vehicle JSON object in a CrossCore message.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")

public class Vehicle {

  private String id;
  private String type;
  @Valid
  private Contact ownersContactId;
  @Valid
  private Contact keeperContactId;
  private String vin;
  private String plateNumber;
  private String make;
  private String model;
  private String color;
  private String vehicleType;
  private String engineSize;
  private String bodyStyle;
  private String yearOfManufacture;
  private String yearOfRegistration;
  @JsonUnwrapped
  private MonetaryAmount monetaryAmount;
  private Boolean driveable;
  private Boolean tracking;
  private String modifications;
  private String engineType;
  private String carTrim;
  private String overnightParkingLocation;

  public static class Type {

    private Type() {}

    public static final String FINANCED = "FINANCED";
    public static final String INSURED = "INSURED";
    public static final String THIRD_PARTY = "THIRD_PARTY";
  }

  public static class VehicleType {

    private VehicleType() {}

    public static final String BICYCLE = "BICYCLE";
    public static final String BUS = "BUS";
    public static final String CAMPER_VAN = "CAMPER_VAN";
    public static final String CAR = "CAR";
    public static final String HGV = "HGV";
    public static final String MOTORBIKE = "MOTORBIKE";
    public static final String OTHER = "OTHER";
    public static final String TAXI = "TAXI";
    public static final String VAN = "VAN";
  }

  public static class BodyStyle {

    private BodyStyle() {}

    public static final String BUS = "BUS";
    public static final String CAMPER = "CAMPER";
    public static final String COMPACT = "COMPACT";
    public static final String CONVERTIBLE = "CONVERTIBLE";
    public static final String COUPE = "COUPE";
    public static final String ESTATE = "ESTATE";
    public static final String HATCHBACK = "HATCHBACK";
    public static final String LIMOUSINE = "LIMOUSINE";
    public static final String MICRO = "MICRO";
    public static final String MINIVAN = "MINIVAN";
    public static final String MPV = "MPV";
    public static final String PEOPLE_CARRIER = "PEOPLE_CARRIER";
    public static final String PICKUP = "PICKUP";
    public static final String SALOON = "SALOON";
    public static final String SPORTS = "SPORTS";
    public static final String STATION_WAGON = "STATION_WAGON";
    public static final String SUB_COMPACT = "SUB_COMPACT";
    public static final String SUV = "SUV";
  }

  public static class EngineType {

    private EngineType() {}

    public static final String BIODIESEL = "BIODIESEL";
    public static final String BIOETHANOL = "BIOETHANOL";
    public static final String DIESEL = "DIESEL";
    public static final String DIESEL_HYBRID = "DIESEL_HYBRID";
    public static final String ELECTRIC = "ELECTRIC";
    public static final String HYDROGEN = "HYDROGEN";
    public static final String LPG = "LPG";
    public static final String PETROL = "PETROL";
    public static final String PETROL_HYBRID = "PETROL_HYBRID";
  }

  public static class OvernightParkingLocation {

    private OvernightParkingLocation() {}

    public static final String DRIVEWAY = "DRIVEWAY";
    public static final String GARAGE = "GARAGE";
    public static final String ON_STREET = "ON_STREET";
  }
}
