package com.experian.eda.crosscore.api.request.payload.contact;

import com.experian.eda.crosscore.api.validation.NotNullElement;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import javax.validation.Valid;

/**
 * Class representing the Contact block in a CrossCore message.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Contact {

  private String id;
  @Valid
  private Person person;
  @Valid
  private Organization organization;
  @Valid
  private List<@NotNullElement Address> addresses;
  @Valid
  private List<@NotNullElement Telephone> telephones;
  @Valid
  private List<@NotNullElement Email> emails;
  @Valid
  private List<@NotNullElement IdentityDocument> identityDocuments;
  @Valid
  private List<@NotNullElement EmploymentHistory> employmentHistory;
  private BankAccount bankAccount;
  @Valid
  private List<@NotNullElement Card> cards;
  @Valid
  private Biometric biometrics;
  @Valid
  private List<@NotNullElement Income> incomes;
}
