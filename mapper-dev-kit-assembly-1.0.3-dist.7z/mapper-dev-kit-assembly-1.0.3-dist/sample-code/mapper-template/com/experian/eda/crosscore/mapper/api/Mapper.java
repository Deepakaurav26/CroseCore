package com.experian.eda.crosscore.mapper.api;

import com.experian.eda.crosscore.mapper.api.exceptions.MapperException;

import java.util.Map;

/**
 * A "mapper" maps the CrossCore message to a particular backing application, calls that backing applicaiton, and maps
 * the response to a format understood by CrossCore.
 *
 * @param <Configuration> The type of the configuration object returned by the {@link #readConfiguration} method.
 */
public interface Mapper<Configuration> extends AutoCloseable {

  /**
   * Read and validate the configuration for this mapper.
   * This method gets called by the Mapper Service whenever the configuration for this mapper changes. It gets passed
   * the raw mapper configuration (already parsed from JSON into a {@link Map}), and its job is to validate it, and
   * convert it into an object that's more efficient to access (like a POJO). The object it returns will then be cached
   * by the Mapper Service and will be provided to subsequent calls of the {@link #call} method. Implementations of this
   * method should throw an exception if the configuration is invalid, as Mapper Service will then log that exception
   * and keep using the previous configuration.
   *
   * @param configuration The raw configuration parsed from JSON into a {@link Map}.
   *
   * @return The converted, validated configuration object of type {@link Configuration}.
   */
  Configuration readConfiguration(Map<String, Object> configuration);

  /**
   * Call the backing application.
   * This method is called with the CrossCore message and the mapper configuration, and its job is to convert that
   * CrossCore message into something that the backing application understands, call the backing application, and return
   * the response from the backing application, converted into a {@link MapperResponse}.
   * <p>
   * If an error occurs that prevents the mapper from producing a useful decision (for example, the call to the backing
   * application failed due to a network error and no response was returned, or the CrossCore message is missing a
   * critical field),
   * you should throw an exception.
   * If it makes sense for the client to know more details about the error (for example, if it's caused by something
   * that the client can fix, like a field that's missing from the message), throw a {@link MapperException} with a message
   * describing the error. The Mapper Service will then catch the {@link MapperException} and include the message provided
   * in the response that's returned to the client.
   * For any other error, just throw a {@link RuntimeException}, or allow the original exception to bubble (don't catch it).
   * The Mapper Service will catch it and log it.
   * <p>
   * If the mapper is still able to produce a useful decision in spite of an error, just include the error in the response ({@link com.experian.eda.crosscore.api.decisionElements.DecisionElements#warningsErrors}).
   *
   * @param message       The CrossCore message, in JSON format, encoded as UTF-8.
   * @param configuration The mapper configuration, created by the {@link #readConfiguration} method.
   *
   * @return The response from the backing application, converted to a {@link MapperResponse} object.
   */
  MapperResponse call(byte[] message, Configuration configuration) throws MapperException;

  /**
   * Shut down the mapper.
   * This will usually be called just before the process exits. Implementations should do any needed clean-up here, or
   * just leave the implementation empty.
   */
  void close() throws Exception;

}
