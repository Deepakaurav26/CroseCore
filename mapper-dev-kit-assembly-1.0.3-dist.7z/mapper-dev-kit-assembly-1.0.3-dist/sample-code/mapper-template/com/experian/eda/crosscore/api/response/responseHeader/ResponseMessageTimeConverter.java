package com.experian.eda.crosscore.api.response.responseHeader;

import com.experian.eda.crosscore.api.DateFormats;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.fasterxml.jackson.databind.util.Converter;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

public class ResponseMessageTimeConverter implements Converter<String, DateTime> {

  private final DateTimeFormatter DTF = DateTimeFormat.forPattern(DateFormats.SECOND)
      .withZone(DateTimeZone.UTC);

  @Override
  public DateTime convert(final String value) {
    if (StringUtils.isNumeric(value)) {
      return new DateTime(Long.parseLong(value) * 1000, DateTimeZone.UTC);
    } else {
      return DTF.parseDateTime(value);
    }
  }

  @Override
  public JavaType getInputType(final TypeFactory typeFactory) {
    return typeFactory.constructSimpleType(String.class, new JavaType[]{});
  }

  @Override
  public JavaType getOutputType(final TypeFactory typeFactory) {
    return typeFactory.constructSimpleType(DateTime.class, new JavaType[]{});
  }
}
