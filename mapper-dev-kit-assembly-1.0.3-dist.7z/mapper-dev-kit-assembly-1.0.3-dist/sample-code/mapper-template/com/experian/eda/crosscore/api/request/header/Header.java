package com.experian.eda.crosscore.api.request.header;

import com.experian.eda.crosscore.api.DateFormats;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.NotBlank;
import org.joda.time.DateTime;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * Object representation of the Header field in CrossCore message.
 */
@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class Header {

  @NotBlank
  @Size(max = 8) // cannot exceed 8 characters due to DA chaining limitation
  private String tenantId;
  @NotBlank
  private String requestType;
  @NotBlank
  private String clientReferenceId;
  private String expRequestId;
  @JsonFormat(pattern = DateFormats.SECOND)
  @NotNull
  private DateTime messageTime;
  @NotNull
  private Options options;

}
