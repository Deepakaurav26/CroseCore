package com.experian.eda.crosscore.standardmapper;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

/**
 * This is the {@code RetryingTransporterConfiguration} provider interface.
 */
public interface RetryingTransporterConfigurationProvider {
  @Valid
  @NotNull
  RetryingTransporterConfiguration getRetryingTransporter();
}
