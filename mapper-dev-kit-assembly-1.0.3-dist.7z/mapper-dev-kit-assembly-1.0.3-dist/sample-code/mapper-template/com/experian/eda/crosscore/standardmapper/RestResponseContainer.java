package com.experian.eda.crosscore.standardmapper;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NonNull;

import java.util.List;
import java.util.Map;

/**
 * This {@code RestResponseContainer} container class is used by {@link RestTransporter}.
 * <p>
 * It contains a request body of type {@code <Body>}, a map representation of {@link #headers}, and context
 * of type {@code <Context>} to share extra meta information that is passed, unchanged,
 * from a {@link RequestContainer} to {@link RestResponseContainer}.
 */
@Getter
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class RestResponseContainer<Body, Context> {

  @NonNull
  private final Body body;
  private final Map<String, List<String>> headers;
  private final Context context;
}
