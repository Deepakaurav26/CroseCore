package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.DateFormats;
import com.experian.eda.crosscore.api.request.payload.contact.Contact;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.DateTime;

import javax.validation.Valid;

/**
 * Class representing the Loyalty Program JSON object in a CrossCore message.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class LoyaltyProgram {

  private String id;
  @Valid
  private Contact customer;
  private String programName;
  private String memberId;
  private String status;
  private String vendorCode;
  private Integer currentPoints;
  private Integer totalPoints;
  @JsonFormat(pattern = DateFormats.DAY)
  private DateTime signupDate;
  @JsonFormat(pattern = DateFormats.DAY)
  private DateTime effectiveDate;
  @JsonFormat(pattern = DateFormats.DAY)
  private DateTime expireDate;
  private String level;

}
