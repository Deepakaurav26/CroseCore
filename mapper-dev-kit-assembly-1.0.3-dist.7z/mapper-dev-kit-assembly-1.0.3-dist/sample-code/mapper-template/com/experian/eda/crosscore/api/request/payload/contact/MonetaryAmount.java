package com.experian.eda.crosscore.api.request.payload.contact;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Class Representing an amount and currency in a CrossCore message.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MonetaryAmount {

  private BigDecimal amount;
  private String currencyCode;
}
