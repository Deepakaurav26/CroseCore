package com.experian.eda.crosscore.api.request.payload.contact;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class representing a full Name JSON object in a CrossCore message.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Name {

  private String id;
  private String type;
  private String title;
  private String firstName;
  private String middleNames;
  private String surName;
  private String initials;
  private String namePrefix;
  private String nameSuffix;
  private String nameCode;

  public static class Type {

    private Type() {}

    public final static String ALIAS = "ALIAS";
    public final static String CURRENT = "CURRENT";
    public final static String FATHER = "FATHER";
    public final static String HUSBAND = "HUSBAND";
    public final static String MAIDEN = "MAIDEN";
    public final static String OTHER = "OTHER";
    public final static String PREVIOUS = "PREVIOUS";
  }

  public static class NameCode {

    private NameCode() {}

    public final static String E = "E";
    public final static String O = "O";
    public final static String P = "P";
    public final static String T = "T";
  }
}
