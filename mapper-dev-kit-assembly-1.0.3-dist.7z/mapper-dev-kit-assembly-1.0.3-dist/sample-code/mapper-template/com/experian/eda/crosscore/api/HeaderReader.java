package com.experian.eda.crosscore.api;

import com.experian.eda.crosscore.api.request.header.Header;
import com.fasterxml.jackson.core.filter.FilteringParserDelegate;
import com.fasterxml.jackson.core.filter.JsonPointerBasedFilter;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import lombok.NonNull;
import lombok.val;

import java.io.IOException;

/**
 * Lets you parse the header of a CrossCore message, ignoring the payload.
 * Much faster than parsing the whole message, if the payload is big.
 */
public class HeaderReader {

  private final JsonPointerBasedFilter tokenFilter = new JsonPointerBasedFilter("/header");
  private final ObjectReader objectReader;

  public HeaderReader(@NonNull ObjectMapper objectMapper) {
    objectReader = objectMapper.reader().forType(Header.class);
  }

  public Header read(byte[] message) throws IOException {
    // A simpler way to do this would be to use an `objectMapper.reader().at("/header").forType(Header.class)`,
    // but that currently doesn't work due to what appears to be a bug in Jackson (causes the test
    // `tenantIdAfterOptions` to fail).
    val parser = new FilteringParserDelegate(
        this.objectReader.getFactory().createParser(message),
        this.tokenFilter,
        false,
        true);
    return objectReader.readValue(parser);
  }

}
