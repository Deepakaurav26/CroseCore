package com.experian.eda.crosscore.standardmapper;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

/**
 * This is the {@code RestTransporterConfiguration} provider interface.
 */
public interface RestTransporterConfigurationProvider {
  @Valid
  @NotNull
  RestTransporterConfiguration getRestTransporter();
}
