package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.request.payload.contact.Address;
import com.experian.eda.crosscore.api.request.payload.contact.Contact;
import com.experian.eda.crosscore.api.validation.NotNullElement;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import javax.validation.Valid;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ExternalLookup {

  private String source;
  private String parameter;
  @JsonProperty(value = "contactId")
  @Valid
  private Contact contact;
  @JsonProperty(value = "addressId")
  private Address address;
  @Valid
  private List<@NotNullElement ExternalDataElement> externalData;
  private Link link;
}
