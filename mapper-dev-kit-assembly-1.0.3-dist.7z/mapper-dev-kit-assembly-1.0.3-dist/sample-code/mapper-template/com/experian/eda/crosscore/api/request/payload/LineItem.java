package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.request.payload.contact.MonetaryAmount;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class LineItem {

  private String id;
  private String name;
  private String description;
  private String sku;
  private String promoCode;
  private String category;
  private UnitWeight unitWeight;
  private Integer quantity;
  private MonetaryAmount unitCost;
  private MonetaryAmount totalCost;
}
