package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.request.payload.contact.Contact;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Store {

  private String storeId;
  @JsonProperty(value = "contactId")
  @Valid
  private Contact contact;
}
