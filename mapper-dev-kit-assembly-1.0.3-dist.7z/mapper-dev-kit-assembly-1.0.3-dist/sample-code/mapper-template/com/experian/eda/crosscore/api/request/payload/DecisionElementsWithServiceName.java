package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.decisionElements.DecisionElements;
import com.fasterxml.jackson.annotation.JsonUnwrapped;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

/**
 * Class representing elements provided for decisioning
 */
@Data
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@FieldDefaults(level = AccessLevel.PRIVATE)
@Builder
public class DecisionElementsWithServiceName {

  String serviceName;
  @JsonUnwrapped
  DecisionElements decisionElements;
}
