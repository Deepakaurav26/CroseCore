package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.validation.NotNullElement;
import com.fasterxml.jackson.annotation.JsonUnwrapped;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import javax.validation.Valid;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class ExternalDataElement {

  @JsonUnwrapped
  private UserDefinedElement userDefinedElement;
  private String externalDataName;
  @Valid
  private List<@NotNullElement ExternalDataElement> externalDataElements;
}
