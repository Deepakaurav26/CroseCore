package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.request.payload.contact.Contact;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;

/**
 * Class representing the AccountHolder JSON object in a CrossCore message.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountHolder {

  private String customerType;
  @JsonProperty(value = "contactId")
  @Valid
  private Contact contact;

  public static class CustomerType {

    public static final String INDIVIDUAL = "INDIVIDUAL";
    public static final String COMMERCIAL = "COMMERCIAL";
  }
}
