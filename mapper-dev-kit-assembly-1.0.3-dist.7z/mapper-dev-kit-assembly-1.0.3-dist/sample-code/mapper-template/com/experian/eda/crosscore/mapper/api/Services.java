package com.experian.eda.crosscore.mapper.api;

import com.experian.eda.crosscore.mapper.api.services.FileStorageService;

/**
 * Services available to a mapper.
 */
public interface Services {

  /**
   * The File Storage Service, used for retrieving files linked to in the request, and storing files to be sent back in the response.
   *
   * @return An object that implements {@link FileStorageService}
   */
  FileStorageService getFileStorageService();

}
