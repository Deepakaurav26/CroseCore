package com.experian.eda.crosscore.standardmapper;

import com.experian.eda.crosscore.mapper.api.exceptions.MapperException;

/**
 * This {@code IdentityTransformer} class is used when the {@link Transformer} class needs to pass the CrossCore
 * message payload as is.
 */
public class IdentityTransformer<Configuration> implements Transformer<byte[], byte[], Configuration> {

  /**
   * Description of the {@code transformRequest} method.
   *
   * @param bytes the CrossCore message in byte[]
   * @param config the Mapper configuration of type Configuration
   * @return the CrossCore message as is
   */
  @Override
  public byte[] transformRequest(final byte[] bytes, final Configuration config) throws MapperException {
    return bytes;
  }

  /**
   * Calls {@link #close()} for all the closeable classes after the end of the call.
   *
   * @return void
   * @throws java.lang.Exception if there is a failure to close
   */
  @Override
  public void close() throws Exception {

  }
}
