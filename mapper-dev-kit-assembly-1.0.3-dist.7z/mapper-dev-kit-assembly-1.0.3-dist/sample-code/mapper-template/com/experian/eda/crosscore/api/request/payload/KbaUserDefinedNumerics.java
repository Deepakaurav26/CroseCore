package com.experian.eda.crosscore.api.request.payload;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class KbaUserDefinedNumerics {

  private String userDefinedNumeric1;
  private String userDefinedNumeric2;
  private String userDefinedNumeric3;
  private String userDefinedNumeric4;
}
