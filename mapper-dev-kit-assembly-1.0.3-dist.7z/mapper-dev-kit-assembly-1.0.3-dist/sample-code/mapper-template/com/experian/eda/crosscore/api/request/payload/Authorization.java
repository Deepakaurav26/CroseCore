package com.experian.eda.crosscore.api.request.payload;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class representing the Authorization JSON object in a CrossCore message.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Authorization {

  private Boolean declined;
  private String approvalCode;
  private String avsAddress;
  private String avsZip;
  private String cvv2;
  private String threeDsecure; //todo: follow up on formatting
  private String enhAuthPhone;
  private String enhAuthName;
  private String enhAuthEmail;
  private String psAddr;
  private String psPayer;

  public static class ApprovalCode {

    private ApprovalCode() {}

    public static final String M = "M";
    public static final String N = "N";
    public static final String X = "X";
  }

  public static class AvsAddress {

    private AvsAddress() {}

    public static final String M = "M";
    public static final String N = "N";
    public static final String X = "X";
  }

  public static class AvsZip {

    private AvsZip() {}

    public static final String M = "M";
    public static final String N = "N";
    public static final String X = "X";
  }

  public static class Cvv2 {

    private Cvv2() {}

    public static final String M = "M";
    public static final String N = "N";
    public static final String X = "X";
  }

  public static class ThreeDsecure {

    private ThreeDsecure() {}

    public static final String M = "M";
    public static final String N = "N";
    public static final String X = "X";
  }

  public static class EnhAuthPhone {

    private EnhAuthPhone() {}

    public static final String M = "M";
    public static final String N = "N";
    public static final String X = "X";
  }

  public static class EnhAuthName {

    private EnhAuthName() {}

    public static final String M = "M";
    public static final String N = "N";
    public static final String X = "X";
  }

  public static class EnhAuthEmail {

    private EnhAuthEmail() {}

    public static final String M = "M";
    public static final String N = "N";
    public static final String X = "X";
  }

  public static class PsAddress {

    private PsAddress() {}

    public static final String C = "C";
    public static final String U = "U";
  }

  public static class PsPayer {

    private PsPayer() {}

    public static final String U = "U";
    public static final String V = "V";
  }
}
