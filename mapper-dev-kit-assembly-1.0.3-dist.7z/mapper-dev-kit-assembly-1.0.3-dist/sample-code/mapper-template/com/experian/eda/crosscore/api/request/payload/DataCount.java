package com.experian.eda.crosscore.api.request.payload;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class representing an data count group from backing service.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DataCount {

  private String name;
  private int value;
}
