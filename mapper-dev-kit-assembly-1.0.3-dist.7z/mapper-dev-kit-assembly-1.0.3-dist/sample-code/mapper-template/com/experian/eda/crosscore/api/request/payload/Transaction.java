package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.DateFormats;
import com.experian.eda.crosscore.api.request.payload.contact.Contact;
import com.experian.eda.crosscore.api.request.payload.contact.MonetaryAmount;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.DateTime;

import javax.validation.Valid;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Transaction {

  private String id;
  private String type;
  private MonetaryAmount cashValue;
  private Integer pointsRedeemed;
  @JsonFormat(pattern = DateFormats.SECOND)
  private DateTime time;
  @JsonProperty(value = "payerContactId")
  @Valid
  private Contact payer;
  private String category;
  @Valid
  private Method method;
  private String transferType;
  @JsonProperty(value = "fromAccountId")
  @Valid
  private FinancialAccount fromAccount;
  @JsonProperty(value = "toAccountId")
  @Valid
  private FinancialAccount toAccount;
  private String memo;
  @JsonProperty(value = "billPayContactId")
  @Valid
  private Contact billPayContact;

  public static class TransactionType {

    private TransactionType() {}

    public static final String BILL_PAY = "BILL_PAY";
    public static final String PAYMENT = "PAYMENT";
    public static final String TRANSFER = "TRANSFER";
  }

  public static class TransferType {

    private TransferType() {}

    public static final String BETWEEN_ACCOUNTS = "BETWEEN_ACCOUNTS";
    public static final String P2P = "P2P";
    public static final String WIRE = "WIRE";
  }

  public static class TransactionCategory {

    private TransactionCategory() {}

    public static final String DEPOSIT = "DEPOSIT";
    public static final String REDEEM = "REDEEM";
    public static final String REFUND = "REFUND";
    public static final String SALE = "SALE";
  }
}
