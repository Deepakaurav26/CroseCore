package com.experian.eda.crosscore.api.request.payload;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class KbaUserDefinedTexts {

  private String userDefinedText1;
  private String userDefinedText2;
  private String userDefinedText3;
  private String userDefinedText4;
}
