package com.experian.eda.crosscore.api.response.responseHeader;

import com.experian.eda.crosscore.api.validation.NotNullElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import javax.validation.Valid;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OverallResponse {

  public static class Decision {

    private Decision() {
    }

    public static final String NODECISION = "NODECISION";
    public static final String ACCEPT = "ACCEPT";
    public static final String REFER = "REFER";
    public static final String REJECT = "REJECT";
  }

  private String decision;
  private Integer score;
  private String decisionText;
  @Valid
  private List<@NotNullElement String> decisionReasons;
  @Valid
  private List<@NotNullElement String> recommendedNextActions;
  @Valid
  private List<@NotNullElement String> spareObjects;

}
