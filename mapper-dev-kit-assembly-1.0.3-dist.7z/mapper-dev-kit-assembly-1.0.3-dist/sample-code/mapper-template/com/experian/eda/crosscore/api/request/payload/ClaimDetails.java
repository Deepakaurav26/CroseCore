package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.DateFormats;
import com.experian.eda.crosscore.api.request.payload.contact.MonetaryAmount;
import com.experian.eda.crosscore.api.request.payload.contact.TimeSpan;
import com.experian.eda.crosscore.api.validation.NotNullElement;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.DateTime;

import java.util.List;
import javax.validation.Valid;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ClaimDetails {

  private String claimStatus;
  private MonetaryAmount finalLoss;
  private String reason;
  private String claimType;
  private String causeOfLoss;
  private Integer noOfClaimants;
  private String damageExtent;
  private Boolean totalLoss;
  private String salvageCode;
  private String description;
  @JsonFormat(pattern = DateFormats.SECOND)
  private DateTime incidentTime;
  private String causeNature;
  private String emergencyServices;
  private TimeSpan speed;
  @Valid
  private List<@NotNullElement Transition> dates;
  private String liability;
  private Boolean liabilityAccept;
  private String injuryDescription;

  public static class Liability {

    private Liability() {}

    public static final String DRIVER_INS_VEHICLE = "DRIVER_INS_VEHICLE";
    public static final String THIRD_PARTY = "THIRD_PARTY";
    public static final String BOTH = "BOTH";
    public static final String CANT_SAY = "CANT_SAY";
  }

  public static class ClaimStatus {

    private ClaimStatus() {}

    public static final String CLOSED = "CLOSED";
    public static final String EX_GPAY = "EX_GPAY";
    public static final String FINALISED = "FINALISED";
    public static final String OPEN = "OPEN";
    public static final String OUTSTANDING = "OUTSTANDING";
    public static final String REOPENED = "REOPENED";
    public static final String REPUDIATED = "REPUDIATED";
    public static final String SETTLED = "SETTLED";
    public static final String SETTLED_NO_COST = "SETTLED_NO_COST";
    public static final String UNAFFECTED = "UNAFFECTED";
    public static final String WITHDRAWN = "WITHDRAWN";
  }

  public static class CauseOfLoss {

    private CauseOfLoss() {}

    public static final String ACC = "ACC";
    public static final String AD = "AD";
    public static final String AL = "AL";
    public static final String BRK = "BRK";
    public static final String COLCY = "COLCY";
    public static final String COLTP = "COLTP";
    public static final String EQ = "EQ";
    public static final String EX = "EX";
    public static final String FD = "FD";
    public static final String FI = "FI";
    public static final String FL = "FL";
    public static final String FT = "FT";
    public static final String FUEL = "FUEL";
    public static final String GL = "GL";
    public static final String IMP = "IMP";
    public static final String KEYS = "KEYS";
    public static final String LI = "LI";
    public static final String LY = "LY";
    public static final String MD = "MD";
    public static final String OL = "OL";
    public static final String OT = "OT";
    public static final String OVER = "OVER";
    public static final String PA = "PA";
    public static final String REAR = "REAR";
    public static final String RIOT = "RIOT";
    public static final String SF = "SF";
    public static final String SL = "SL";
    public static final String ST = "ST";
    public static final String TA = "TA";
    public static final String TC = "TC";
    public static final String TH = "TH";
    public static final String TL = "TL";
    public static final String TPPRP = "TPPRP";
    public static final String TPREV = "TPREV";
    public static final String TPROW = "TPROW";
    public static final String TPSHT = "TPSHT";
    public static final String TT = "TT";
    public static final String TV = "TV";
    public static final String U = "U";
    public static final String WD = "WD";
    public static final String WS = "WS";
  }
}
