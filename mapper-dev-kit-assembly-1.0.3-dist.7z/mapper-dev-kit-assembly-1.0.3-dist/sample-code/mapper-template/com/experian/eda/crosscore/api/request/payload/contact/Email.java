package com.experian.eda.crosscore.api.request.payload.contact;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class representing an Email in a CrossCore message.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Email {

  private String id;
  private String type;
  private String email;

  public static class Type {

    private Type() {}

    public static final String HOME = "HOME";
    public static final String WORK = "WORK";
    public static final String OTHER = "OTHER";
    public static final String UNKNOWN = "UNKNOWN";
  }
}
