package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.DateFormats;
import com.experian.eda.crosscore.api.request.payload.contact.Contact;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.DateTime;

import javax.validation.Valid;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class UserAccount {

  private String id;
  private String userAccountId;
  private String username;
  private String hashedPassword;
  @JsonFormat(pattern = DateFormats.SECOND)
  private DateTime enrolmentTime;
  @Valid
  private UserAccountHolder accountHolder;
  private Boolean returnCustomer;
  private LastActionTimes lastActionTimes;
  @JsonProperty(value = "loyaltyProgramId")
  @Valid
  private LoyaltyProgram loyaltyProgram;
  private Boolean currentlyTraveling;
}