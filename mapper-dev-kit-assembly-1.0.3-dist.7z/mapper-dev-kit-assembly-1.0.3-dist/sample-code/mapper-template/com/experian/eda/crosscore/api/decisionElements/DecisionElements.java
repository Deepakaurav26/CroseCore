package com.experian.eda.crosscore.api.decisionElements;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@FieldDefaults(level = AccessLevel.PRIVATE)
@Builder
public class DecisionElements {

  String applicantId;
  String decision;
  Integer score;
  String decisionText;
  String decisionReason;
  String appReference;
  List<Rule> rules;
  List<WarningOrError> warningsErrors;
  Map<String, Object> otherData;
  List<Decision> decisions;
  List<Match> matches;
  List<DataCount> dataCounts;
  List<Score> scores;
  List<Record> records;
}
