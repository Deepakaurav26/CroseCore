package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.DateFormats;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.DateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Transition {

  private String dateType;
  @JsonFormat(pattern = DateFormats.DAY)
  private DateTime date;

  public static class DateType {

    private DateType() {}

    public static final String ADDED_DATE = "ADDED_DATE";
    public static final String ATTACHED_DATE = "ATTACHED_DATE";
    public static final String CLAIM_CLOSED = "CLAIM_CLOSED";
    public static final String COVER_START = "COVER_START";
    public static final String EFFECTIVE_DATE = "EFFECTIVE_DATE";
    public static final String EXPIRY_DATE = "EXPIRY_DATE";
    public static final String LOSS_DATE = "LOSS_DATE";
    public static final String NATIONAL_INSURANCE = "NATIONAL_INSURANCE";
    public static final String NOTIFICATION_DATE = "NOTIFICATION_DATE";
    public static final String ORIGINAL_INCEPTION_DATE = "ORIGINAL_INCEPTION_DATE";
    public static final String POLICY_END_DATE = "POLICY_END_DATE";
    public static final String RENEWAL_DATE = "RENEWAL_DATE";
    public static final String TERMINATED_DATE = "TERMINATED_DATE";
  }
}
