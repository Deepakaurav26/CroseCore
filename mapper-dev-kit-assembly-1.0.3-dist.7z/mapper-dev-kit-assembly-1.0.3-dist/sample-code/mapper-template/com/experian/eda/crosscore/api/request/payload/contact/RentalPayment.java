package com.experian.eda.crosscore.api.request.payload.contact;

import com.fasterxml.jackson.annotation.JsonUnwrapped;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RentalPayment {

  @JsonUnwrapped
  private MonetaryAmount monetaryAmount;
  private String frequency;
  private String type;

  public static class Frequency {

    private Frequency() {}

    public final static String HOURLY = "HOURLY";
    public final static String DAILY = "DAILY";
    public final static String WEEKLY = "WEEKLY";
    public final static String BIWEEKLY = "BIWEEKLY";
    public final static String MONTHLY = "MONTHLY";
    public final static String SEMI_MONTHLY = "SEMI_MONTHLY";
    public final static String YEARLY = "YEARLY";
    public final static String QUATERLY = "QUATERLY";
    public final static String SEMI_ANNUALLY = "SEMI_ANNUALLY";
    public final static String ANNUALLY = "ANNUALLY";
  }

  public static class Type {

    private Type() {}

    public final static String MORTGAGE = "MORTGAGE";
    public final static String RENTAL = "RENTAL";
  }
}
