package com.experian.eda.crosscore.standardmapper;

import com.experian.eda.crosscore.mapper.api.exceptions.MapperException;
import com.github.rholder.retry.RetryException;
import com.github.rholder.retry.RetryerBuilder;
import com.github.rholder.retry.StopStrategies;
import com.github.rholder.retry.WaitStrategies;
import com.google.common.base.Throwables;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import lombok.val;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

/**
 * This {@code RetryingTransporter} class implements {@link Transporter} and can be used as a wrapper
 * transporter that implements retry logic for {@link Transporter#call}.
 * <p>
 * The retryer class used by this class is configured by {@link RetryingTransporterConfiguration}.
 *
 * @param <TransformerResult> the class type for the transformed request that gets passed as a transformerResult
 *                            parameter and is a result of {@link Transformer#transformRequest}
 * @param <TransporterResult> the class type for the response that is returned by calling {@code inner#transport}
 * @param <Configuration> the class type for {@link MapperConfiguration} and stores value for all the
 *                        configuration related to the mapper.
 *                        In the {@link RetryingTransporter} context this configuration has to also extend
 *                        {@link RetryingTransporterConfiguration} that would be used by the retryer.
 */
@Slf4j
@AllArgsConstructor
public class RetryingTransporter<TransformerResult, TransporterResult, Configuration extends RetryingTransporterConfigurationProvider>
    implements Transporter<TransformerResult, TransporterResult, Configuration> {

  /*
   * The Transporter#transport call is delegated to this by the retryer.
   * If a retry exception is thrown by this call the retryer will call it again until it's max tries are
   * exhausted.
   */
  @NonNull
  private final Transporter<TransformerResult, TransporterResult, Configuration> inner;

  /**
   * This {@code transport} method ...
   *
   * @param transformerResult the transformed request that gets passed as a transformerResult parameter and
   *                          is a result of Transformer#transformRequest
   * @param config the mapper configuration of type {@literal <Configuration>} and stores value for all the configuration
   *               related to the mapper. In this RetryingTransporter context, this configuration has to also extend
   *               RetryingTransporterConfiguration that would be used by the retryer.
   * @return the result of inner#transport which is of type {@literal <TransportResult>}
   * @throws MapperException if mapper exception is thrown by inner.transport or if Retry calls have been exhausted
   * @throws RuntimeException if retryer#call throws the same
   */
  @Override
  public TransporterResult transport(final TransformerResult transformerResult, final Configuration config)
      throws MapperException {
    val retryer = RetryerBuilder.<TransporterResult>newBuilder()
        .retryIfExceptionOfType(RetriableMapperException.class)
        .withWaitStrategy(
            config.getRetryingTransporter().isExponentialRetryStrategy() ?
            WaitStrategies.exponentialWait(config.getRetryingTransporter().getBaseDelayMillis(),
                                           config.getRetryingTransporter().getMaxDelayMillis(),
                                           TimeUnit.MILLISECONDS) :
            WaitStrategies.fixedWait(config.getRetryingTransporter().getBaseDelayMillis(),
                                     TimeUnit.MILLISECONDS)
        )
        .withStopStrategy(StopStrategies.stopAfterAttempt(config.getRetryingTransporter().getMaxTries()))
        .build();
    try {
      return retryer.call(() -> inner.transport(transformerResult, config));
    } catch (ExecutionException | RetryException e) {
      Throwables.propagateIfPossible(Throwables.getRootCause(e), RuntimeException.class, MapperException.class);
    }
    return inner.transport(transformerResult, config);
  }
  /**
   * Calls {@link #close()} for all the closeable classes after the end of the call.
   *
   * @return void
   * @throws java.lang.Exception if there is a failure to close
   */
  @Override
  public void close() throws Exception {
    inner.close();
  }
}
