package com.experian.eda.crosscore.api;

public class DateFormats {

  public static final String MILLISECOND = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
  public static final String SECOND = "yyyy-MM-dd'T'HH:mm:ss'Z'";
  public static final String DAY = "yyyy-MM-dd";

  private DateFormats() {
  }

}
