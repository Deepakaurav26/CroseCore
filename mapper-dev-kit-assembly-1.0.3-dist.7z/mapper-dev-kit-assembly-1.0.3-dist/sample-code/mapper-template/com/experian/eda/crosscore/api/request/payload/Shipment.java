package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.DateFormats;
import com.experian.eda.crosscore.api.request.payload.contact.Contact;
import com.experian.eda.crosscore.api.request.payload.contact.MonetaryAmount;
import com.experian.eda.crosscore.api.validation.NotNullElement;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.DateTime;

import javax.validation.Valid;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Shipment {

  @JsonProperty(value = "recipientContactId")
  @Valid
  private Contact recipientContact;
  @JsonFormat(pattern = DateFormats.SECOND)
  private DateTime scheduledShipTime;
  private Boolean insured;
  private String method;
  private MonetaryAmount cost;
  @JsonProperty(value = "lineItemIds")
  @Valid
  private List<@NotNullElement LineItem> lineItems;

  public static class Method {

    private Method() {}

    public static final String DIGITAL = "DIGITAL";
    public static final String GROUND = "GROUND";
    public static final String IN_STORE = "IN_STORE";
    public static final String OVERNIGHT = "OVERNIGHT";
    public static final String SAME_DAY = "SAME_DAY";
    public static final String THIRD_DAY = "THIRD_DAY";
    public static final String UNKNOWN = "UNKNOWN";
  }
}
