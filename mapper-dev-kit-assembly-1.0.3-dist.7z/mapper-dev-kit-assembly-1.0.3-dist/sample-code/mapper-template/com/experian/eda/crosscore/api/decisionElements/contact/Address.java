package com.experian.eda.crosscore.api.decisionElements.contact;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@FieldDefaults(level = AccessLevel.PRIVATE)
@Builder
public class Address {

  private String id;
  private String addressType;
  private String street;
  private String street2;
  private String county;
  private String postTown;
  private String postal;
  private String stateProvinceCode;
  private String countryCode;

  public static class AddressType {

    private AddressType() {}

    public static final String BILLING = "BILLING";
    public static final String CORRESPONDANCE = "CORRESPONDANCE";
    public static final String CURRENT = "CURRENT";
    public static final String DELIVERY = "DELIVERY";
    public static final String GARAGE = "GARAGE";
    public static final String INCIDENT_LOCATION = "INCIDENT_LOCATION";
    public static final String INSPECTION_ADDRESS = "INSPECTION_ADDRESS";
    public static final String INSURED_ADDRESS = "INSURED_ADDRESS";
    public static final String LINKED = "LINKED";
    public static final String PREVIOUS = "PREVIOUS";
    public static final String PRIMARY = "PRIMARY";
    public static final String REGISTERED_OFFICE = "REGISTERED_OFFICE";
    public static final String RISK = "RISK";
    public static final String SECONDARY = "SECONDARY";
    public static final String TRADING = "TRADING";
  }
}
