package com.experian.eda.crosscore.api.request.payload;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class representing the User Identity Cookie JSON object in a CrossCore message.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserIdentityCookie {

  private String key;
  private String value;
}
