package com.experian.eda.crosscore.api.request.payload.contact;

import com.fasterxml.jackson.annotation.JsonUnwrapped;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class NetProfitYear {

  private String year;
  @JsonUnwrapped
  private MonetaryAmount monetaryAmount;
}
