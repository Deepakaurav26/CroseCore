package com.experian.eda.crosscore.mapper.api;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

import java.util.List;

/**
 * Provides information about a mapper.
 */
@Value
@Builder
@AllArgsConstructor
public class MapperInformation {

  /**
   * The name of the mapper.
   */
  @NonNull
  String name;

  /**
   * The versions of the backing application that the mapper supports.
   * Note that this is not the same as the version of the mapper.
   */
  @NonNull
  List<String> supportedBackingApplicationVersions;
}
