package com.experian.eda.crosscore.api.request.payload.contact;

import com.experian.eda.crosscore.api.DateFormats;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.DateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PersonDetails {

  @JsonFormat(pattern = DateFormats.DAY)
  private DateTime dateOfBirth;
  private String yearOfBirth;
  private Integer age;
  private String gender;
  private String placeOfBirth;
  private String countryOfBirth;
  private String nationalityCountryCode;
  @JsonFormat(pattern = DateFormats.DAY)
  private DateTime dateOfDeath;
  private String mothersMaidenName;
  private String spouseName;
  private Integer noOfDependents;
  private String occupancyStatus;
  private String maritalStatus;
  private String dateOfBirthType;
  private String qualificationType;
  private String firstTimeBuyer;
  private String isBankrupt;
  private RentalPayment mortgageRentalPayment;
  private MonetaryAmount outstandingMortgage;
  private String relationshipType;
  private String principleRole;
  @JsonFormat(pattern = DateFormats.DAY)
  private DateTime ownerSince;
  private String ownerShare;
  private String mothersFullName;
  private String occupation;

  public static class DateOfBirthType {

    private DateOfBirthType() {}

    public static final String A = "A";
    public static final String D = "D";
    public static final String V = "V";
  }

  public static class Gender {

    private Gender() {}

    public static final String M = "M";
    public static final String F = "F";
    public static final String U = "U";
    public static final String OTH = "OTH";
  }

  public static class OccupancyStatus {

    private OccupancyStatus() {}

    public static final String DTB = "DTB";
    public static final String DTH = "DTH";
    public static final String FAM = "FAM";
    public static final String FRI = "FRI";
    public static final String JTO = "JTO";
    public static final String LPA = "LPA";
    public static final String LWP = "LWP";
    public static final String OTH = "OTH";
    public static final String OUT = "OUT";
    public static final String OWE = "OWE";
    public static final String OWN = "OWN";
    public static final String OWO = "OWO";
    public static final String Q = "Q";
    public static final String RNTCO = "RNTCO";
    public static final String RTP = "RTP";
    public static final String SDH = "SDH";
    public static final String SHR = "SHR";
    public static final String SMD = "SMD";
    public static final String TEN = "TEN";
    public static final String TNFUR = "TNFUR";
    public static final String TNU = "TNU";
    public static final String TRC = "TRC";
    public static final String Z = "Z";
  }

  public static class MaritalStatus {

    private MaritalStatus() {}

    public static final String C = "C";
    public static final String CIP = "CIP";
    public static final String D = "D";
    public static final String DIV = "DIV";
    public static final String LIV = "LIV";
    public static final String M = "M";
    public static final String MAR = "MAR";
    public static final String MIP = "MIP";
    public static final String OTH = "OTH";
    public static final String S = "S";
    public static final String SEP = "SEP";
    public static final String SIN = "SIN";
    public static final String SPD = "SPD";
    public static final String UNK = "UNK";
    public static final String W = "W";
    public static final String WID = "WID";
    public static final String X = "X";
  }

  public static class QualificationType {

    private QualificationType() {}

    public static final String BELOW_MATRIC = "BELOW_MATRIC";
    public static final String COLLEGE = "COLLEGE";
    public static final String DEGREE = "DEGREE";
    public static final String DIPLOMA = "DIPLOMA";
    public static final String DOCTORATE = "DOCTORATE";
    public static final String ENGINEER = "ENGINEER";
    public static final String GRADUATE_PHD = "GRADUATE_PHD";
    public static final String HIGH_SCHOOL = "HIGH_SCHOOL";
    public static final String HSC = "HSC";
    public static final String ILLITERATE = "ILLITERATE";
    public static final String IT_TECH_DIPLOMA = "IT_TECH_DIPLOMA";
    public static final String MATRIC = "MATRIC";
    public static final String OTHER = "OTHER";
    public static final String POST_GRADUATE = "POST_GRADUATE";
    public static final String PROFESSIONAL = "PROFESSIONAL";
    public static final String UNDER_GRADUATE = "UNDER_GRADUATE";
    public static final String UNFINISHED_UNIVERSITY = "UNFINISHED_UNIVERSITY";
    public static final String UNIVERSITY = "UNIVERSITY";
  }

  public static class RelationshipType {

    private RelationshipType() {}

    public static final String FATHER = "FATHER";
    public static final String MOTHER = "MOTHER";
    public static final String SISTER = "SISTER";
    public static final String BROTHER = "BROTHER";
    public static final String SPOUSE = "SPOUSE";
    public static final String OTHER = "OTHER";
  }
}
