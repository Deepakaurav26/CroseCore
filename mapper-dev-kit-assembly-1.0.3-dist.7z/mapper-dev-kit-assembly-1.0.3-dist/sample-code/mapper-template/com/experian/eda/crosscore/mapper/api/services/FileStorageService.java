package com.experian.eda.crosscore.mapper.api.services;

/**
 * The File Storage Service.
 */
public interface FileStorageService {

  /**
   * Retrieve a file.
   *
   * @param uuid The file UUID
   *
   * @return The file data
   */
  byte[] get(String uuid);

  /**
   * Save a file.
   *
   * @param data     The file data
   * @param tenantId The tenant ID
   *
   * @return The file UUID.
   */
  String save(byte[] data, String tenantId);

}
