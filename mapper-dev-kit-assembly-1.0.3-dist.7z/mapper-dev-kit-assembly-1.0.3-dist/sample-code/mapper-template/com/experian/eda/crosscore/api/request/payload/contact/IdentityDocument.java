package com.experian.eda.crosscore.api.request.payload.contact;

import com.experian.eda.crosscore.api.DateFormats;
import com.experian.eda.crosscore.api.validation.NotNullElement;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.DateTime;

import java.util.List;
import javax.validation.Valid;

/**
 * Class representing an Identity Document JSON object in a CrossCore message.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class IdentityDocument {

  private String id;
  private String documentNumber;
  private String hashedDocumentNumber;
  private String documentType;
  @JsonFormat(pattern = DateFormats.DAY)
  private DateTime validFromDate;
  @JsonFormat(pattern = DateFormats.DAY)
  private DateTime expiresDate;
  private String personalNumber;
  private String nationalityCountryCode;
  private String issueCountryCode;
  private String stateProvinceCode;
  private String issueAuthority;
  @JsonProperty(value = "MRZLine1")
  private String mrzLine1;
  @JsonProperty(value = "MRZLine2")
  private String mrzLine2;
  @JsonProperty(value = "MRZLine3")
  private String mrzLine3;
  private String placeOfBirth;
  private String countryOfBirth;
  private ContactName documentName;
  @JsonFormat(pattern = DateFormats.DAY)
  private DateTime documentDateOfBirth;
  private ContactName mrzName;
  @JsonProperty(value = "documentAddressId")
  private Address address;
  @Valid
  private List<@NotNullElement Image> images;
  private EncodedData encodedData;

  public static class DocumentType {

    private DocumentType() {}

    public static final String AADHAR = "AADHAR";
    public static final String COMPANY_TAN = "COMPANY_TAN";
    public static final String DRIVER_LICENSE = "DRIVER_LICENSE";
    public static final String ECINUMBER = "ECINUMBER";
    public static final String IDCARD = "IDCARD";
    public static final String MEDICARE = "MEDICARE";
    public static final String NATIONAL_ID = "NATIONAL_ID";
    public static final String NATIONAL_INSURANCE = "NATIONAL_INSURANCE";
    public static final String PAN = "PAN";
    public static final String PASSPORT = "PASSPORT";
    public static final String PERSONAL_NUMBER = "PERSONAL_NUMBER";
    public static final String SIN = "SIN";
    public static final String SSN = "SSN";
    public static final String TAX_NUMBER = "TAX_NUMBER";
    public static final String TRAVEL_VISA = "TRAVEL_VISA";
    public static final String VOTER_ID = "VOTER_ID";
  }
}
