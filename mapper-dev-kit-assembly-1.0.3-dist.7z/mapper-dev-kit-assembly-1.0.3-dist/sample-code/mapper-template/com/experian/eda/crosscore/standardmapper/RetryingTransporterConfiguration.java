package com.experian.eda.crosscore.standardmapper;

import com.experian.eda.crosscore.standardmapper.validation.RetryConfig;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Min;

/**
 * This is a Configuration class that is used by {@code RetryingTransporter} to configure the retryer.
 */
@RetryConfig
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RetryingTransporterConfiguration {

  /*
   * Maximum amount of tries for Retryer. Min value is restricted to 1 and default is 3
   */
  @Min(value = 1)
  int maxTries = 3;
  /*
   * Boolean that represents whether Retryer will implement an exponentially delayed retry strategy, defaults to {@code
   * false}
   */
  boolean exponentialRetryStrategy;
  /*
   * Max delay between retry calls. Min value is restricted to 1 and default is 1000 milliseconds
   */
  @Min(value = 1)
  int maxDelayMillis = 1000;
  /*
   * Base delay between retry calls. Min value is restricted to 0 and default is 100 milliseconds
   */
  @Min(value = 0)
  int baseDelayMillis = 100;

}
