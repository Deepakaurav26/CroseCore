package com.experian.eda.crosscore.api.request.payload;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UnitWeight {

  private BigDecimal weight;
  private String unit;

  public static class Unit {

    private Unit() {}

    public static final String GRAM = "GRAM";
    public static final String KILOGRAM = "KILOGRAM";
    public static final String OUNCE = "OUNCE";
    public static final String POUND = "POUND";
    public static final String UNKNOWN = "UNKNOWN";
  }
}
