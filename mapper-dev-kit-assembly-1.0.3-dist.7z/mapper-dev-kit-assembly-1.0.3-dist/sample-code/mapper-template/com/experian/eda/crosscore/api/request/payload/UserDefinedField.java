package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.validation.NotNullElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import javax.validation.Valid;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserDefinedField {

  private String userDefinedTableName;
  @Valid
  private List<@NotNullElement UserDefinedElement> userDefinedElements;
}
