package com.experian.eda.crosscore.api.request.payload;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class representing the Header JSON object in a CrossCore message.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Header {

  private String headerName;
  private String headerValue;
}
