package com.experian.eda.crosscore.api.response.clientResponsePayload;

import com.experian.eda.crosscore.api.DateFormats;
import com.experian.eda.crosscore.api.validation.NotNullElement;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.DateTime;

import java.util.List;
import javax.validation.Valid;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OrchestrationDecision {

  private String sequenceId;
  private String decisionSource;
  private String decision;
  @Valid
  private List<@NotNullElement String> decisionReasons;
  private Integer score;
  private String decisionText;
  private String nextAction;
  private String appReference;
  @JsonFormat(pattern = DateFormats.SECOND)
  private DateTime decisionTime;

}
