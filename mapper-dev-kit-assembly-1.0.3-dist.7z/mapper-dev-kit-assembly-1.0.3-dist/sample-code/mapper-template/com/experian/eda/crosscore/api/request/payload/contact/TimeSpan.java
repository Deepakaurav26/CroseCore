package com.experian.eda.crosscore.api.request.payload.contact;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TimeSpan {

  private String unit;
  private Integer value;

  public static class Unit {

    private Unit() {}

    public final static String DAY = "DAY";
    public final static String WEEK = "WEEK";
    public final static String MONTH = "MONTH";
    public final static String YEAR = "YEAR";
  }
}
