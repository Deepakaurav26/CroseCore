package com.experian.eda.crosscore.api.decisionElements.contact;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@FieldDefaults(level = AccessLevel.PRIVATE)
@Builder
public class Image {

  private String id;
  private String imageData;
  private String documentPart;

  public static class DocumentPart {

    private DocumentPart() {}

    public static final String CROPPED_DOCUMENT = "CroppedDocument";
    public static final String CROPPED_PORTRAIT = "CroppedPortrait";
    public static final String CROPPED_SIGNATURE = "CroppedSignature";
  }
}
