package com.experian.eda.crosscore.api.request.payload.contact;

import com.experian.eda.crosscore.api.DateFormats;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.DateTime;

/**
 * Class representing the Bank Account JSON object in a CrossCore message.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class BankAccount {

  private String id;
  @JsonFormat(pattern = DateFormats.DAY)
  private DateTime openedDate;
  @JsonFormat(pattern = DateFormats.DAY)
  private DateTime closedDate;
  private MonetaryAmount balance;
  private String hashedAccountNumber;
  private String routingNumber;
  private String sortCode;
  private String clearAccountNumber;
  private String rollNumber;
  private String accountCode;
  @JsonProperty(value = "IBAN")
  private String iban;
  @JsonProperty(value = "BIC")
  private String bic;
  private String branch;
  private String type;
  private TimeSpan timeWithBank;
  private String bankName;
  private String accountName;
  @JsonFormat(pattern = DateFormats.DAY)
  private DateTime startDate;
  @JsonFormat(pattern = DateFormats.DAY)
  private DateTime expireDate;
  private String cardLast4Digits;
  private String issueNumber;
  private String securityCode;

  public static class Type {

    private Type() {}

    public static final String CHEQUE = "CHEQUE";
    public static final String CREDIT_CARD = "CREDIT_CARD";
    public static final String CURRENT = "CURRENT";
    public static final String JOINT = "JOINT";
    public static final String SAVINGS = "SAVINGS";
    public static final String SINGLE = "SINGLE";
    public static final String TRANSMISSION = "TRANSMISSION";
  }
}
