package com.experian.eda.crosscore.api.request;

import com.experian.eda.crosscore.api.request.header.Header;
import com.experian.eda.crosscore.api.request.payload.Payload;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RequestMessage {

  @Valid
  @NotNull
  private Header header;
  @Valid
  @NotNull
  private Payload payload;

}
