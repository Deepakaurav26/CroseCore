package com.experian.eda.crosscore.standardmapper;

import com.experian.eda.crosscore.mapper.api.exceptions.MapperException;
import com.google.common.base.Throwables;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import lombok.val;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.stream.Collectors;

/**
 * This {@code ConcurrentTransporter} class is a wrapper transporter.
 * <p>
 * It is used when a list of requests is returned by the {@link Transformer}.
 * Each request is executed concurrently by delegating the transport call to {@link #inner}.
 */
@AllArgsConstructor
@Slf4j
public class ConcurrentTransporter<TransformerResultPart, TransporterResultPart, Configuration>
    implements Transporter<List<TransformerResultPart>, List<TransporterResultPart>, Configuration> {

  /*
   * A nested class that {@link ConcurrentTransporter} will delegate {@link Transporter#transport} to.
   */
  @NonNull
  private final Transporter<TransformerResultPart, TransporterResultPart, Configuration> inner;
  /*
   * ExecutorService that will process multiple threads and delegate to nested transporter inner.
   * The number of threads will depend on the size of the transformerResult returned by Transformer#transformRequest.
   */
  @NonNull
  private final ExecutorService executorService;

  /**
   * This {@code transport} method will take each {@code transformerResultPart} and execute it in a separate thread by delegating
   * the transport call to {@link #inner}.
   *
   * @param transformerResultParts the collection returned by the {@link Transformer#transformRequest} where
   *                               each value in the collection will be executed in a separate thread
   * @param config the mapper configuration
   * @return the collection of transporter responses collected from each thread
   * @throws MapperException if {@link #inner} throws {@link MapperException}
   * @throws RuntimeException if InterruptedException or ExecutionException is thrown by the
   *         executorService
   */
  @Override
  public List<TransporterResultPart> transport(final List<TransformerResultPart> transformerResultParts,
                                               final Configuration config) throws MapperException {
    val result = new ArrayList<TransporterResultPart>();
    val futures = transformerResultParts.stream().map(transformerResultPart -> {
      return executorService.submit(() -> inner.transport(transformerResultPart, config));
    }).collect(Collectors.toList());

    for (val future : futures) {
      try {
        result.add(future.get());
      } catch (InterruptedException | ExecutionException e) {
        Throwables.propagateIfPossible(Throwables.getRootCause(e), RuntimeException.class, MapperException.class);
      }
    }
    return result;
  }
  /**
   * Calls {@link #close()} for all the closeable classes after the end of the call.
   *
   * @return void
   * @throws java.lang.Exception if there is a failure to close
   */
  @Override
  public void close() throws Exception {
    inner.close();
  }
}
