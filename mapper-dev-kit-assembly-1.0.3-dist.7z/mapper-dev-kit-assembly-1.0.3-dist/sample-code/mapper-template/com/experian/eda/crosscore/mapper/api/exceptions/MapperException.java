package com.experian.eda.crosscore.mapper.api.exceptions;

import com.experian.eda.crosscore.api.decisionElements.WarningOrError;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NonNull;
import lombok.experimental.FieldDefaults;

import java.util.Collections;
import java.util.List;

/**
 * Exception indicating that a mapper call failed.
 * It contains a list of errors to include in the response to the client.
 */
@Getter
@FieldDefaults(makeFinal = true, level = AccessLevel.PRIVATE)
public class MapperException extends Exception {

  /**
   * Details about the errors that occurred, to be included in the response to the client.
   */
  List<WarningOrError> errors;

  /**
   * Construct a MapperException for multiple errors.
   *
   * @param errors List of errors to show the client. Must not be null or empty.
   */
  public MapperException(@NonNull List<WarningOrError> errors) {
    if (errors.isEmpty()) {
      throw new IllegalArgumentException("errors is empty");
    }
    this.errors = errors;
  }

  /**
   * Construct a MapperException for a single error.
   * Most of the time you should use the other constructor that takes a {@link String}. Only use this one if you need to
   * set the {@link WarningOrError#responseCode} of the error.
   *
   * @param error The error to show to the client. Must not be null.
   */
  public MapperException(@NonNull WarningOrError error) {
    this(Collections.singletonList(error));
  }

  /**
   * Construct a MapperException for a single error.
   *
   * @param message Details about the error to show to the client. Must not be null.
   */
  public MapperException(@NonNull String message) {
    this(WarningOrError
             .builder()
             .responseType(WarningOrError.ResponseType.ERROR)
             .responseMessage(message)
             .build());
  }

  @Override
  public String getMessage() {
    return String.valueOf(errors);
  }

}
