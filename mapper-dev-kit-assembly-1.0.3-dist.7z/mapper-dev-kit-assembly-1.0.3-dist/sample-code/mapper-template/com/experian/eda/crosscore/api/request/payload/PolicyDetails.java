package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.request.payload.contact.MonetaryAmount;
import com.experian.eda.crosscore.api.validation.NotNullElement;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import javax.validation.Valid;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PolicyDetails {

  @JsonProperty(value = "vehicleIds")
  @Valid
  private List<@NotNullElement Vehicle> vehicles;
  private String coverType;
  private String policyNumber;
  private String policyStatus;
  private MonetaryAmount premium;
  private MonetaryAmount sumInsured;
  private String policyPaymentMethod;
  private MonetaryAmount policyExcess;
  private Integer noOfYearsNoClaimsDiscount;
  private Integer noClaimFreeYears;
  private Integer noOfPreviousClaims;
  private Integer yearsDriverLicenseHeld;
  @Valid
  private List<@NotNullElement String> policyOptions;
  @JsonProperty(value = "dates")
  @Valid
  private List<@NotNullElement Transition> transitions;
  private String travelDestination;
  private Boolean permanentUkResident;
  @Valid
  private List<@NotNullElement String> existingMedicalConditions;
  private PetDetails petDetails;
  private Integer annualMileage;
  private Integer noOfPolicyPrevVoided;

  public static class CoverType {

    private CoverType() {}

    public static final String ACCIDENTAL_DAMAGE = "ACCIDENTAL_DAMAGE";
    public static final String ACCIDENTAL_DMG_FIRETHEFT = "ACCIDENTAL_DMG_FIRETHEFT";
    public static final String ADVENTURE_ACTIVITIES = "ADVENTURE_ACTIVITIES";
    public static final String BAR_INSURANCE = "BAR_INSURANCE";
    public static final String BREAKDOWN = "BREAKDOWN";
    public static final String BUILDINGS = "BUILDINGS";
    public static final String BUILDINGS_CONTENTS = "BUILDINGS_CONTENTS";
    public static final String BUSINESS = "BUSINESS";
    public static final String BUSINESS_INUSRANCE_OTHER = "BUSINESS_INUSRANCE_OTHER";
    public static final String COMERCIAL_PROPERTY = "COMERCIAL_PROPERTY";
    public static final String COMPREHENSIVE = "COMPREHENSIVE";
    public static final String CONTENTS = "CONTENTS";
    public static final String CRITICAL_ILLNESS = "CRITICAL_ILLNESS";
    public static final String CRUISE = "CRUISE";
    public static final String EMERGENCY_REPAIR = "EMERGENCY_REPAIR";
    public static final String EUROPEAN = "EUROPEAN";
    public static final String HEALTH_JOINT = "HEALTH_JOINT";
    public static final String HEALTH_SINGLE = "HEALTH_SINGLE";
    public static final String HOTEL_INSURANCE = "HOTEL_INSURANCE";
    public static final String INCOME_PROTECTION = "INCOME_PROTECTION";
    public static final String LANDLORD = "LANDLORD";
    public static final String LIFE_JOINT = "LIFE_JOINT";
    public static final String LIFE_SINGLE = "LIFE_SINGLE";
    public static final String MEDICAL = "MEDICAL";
    public static final String MORTGAGE_PROTECTION = "MORTGAGE_PROTECTION";
    public static final String MULTI_ANNUAL = "MULTI_ANNUAL";
    public static final String MULTI_TRAVELLER = "MULTI_TRAVELLER";
    public static final String NEW_BUILD = "NEW_BUILD";
    public static final String OTHER = "OTHER";
    public static final String PET_ACCIDENT_ONLY = "PET_ACCIDENT_ONLY";
    public static final String PET_LIFETIME = "PET_LIFETIME";
    public static final String PET_LIMITED_TIME = "PET_LIMITED_TIME";
    public static final String PET_MAX_BENEFIT = "PET_MAX_BENEFIT";
    public static final String PUBLIC_LIABILITY = "PUBLIC_LIABILITY";
    public static final String REDUNDANCY = "REDUNDANCY";
    public static final String RESTAURANT_INSURANCE = "RESTAURANT_INSURANCE";
    public static final String SHOP_INSURANCE = "SHOP_INSURANCE";
    public static final String SINGLE_TRAVELLER = "SINGLE_TRAVELLER";
    public static final String SINGLE_TRIP = "SINGLE_TRIP";
    public static final String THEFT = "THEFT";
    public static final String THIRDPARTY_ONLY = "THIRDPARTY_ONLY";
    public static final String TP_FIRE = "TP_FIRE";
    public static final String TP_FIRETHEFT = "TP_FIRETHEFT";
    public static final String TP_FIRETHEFT_MALICIOUS = "TP_FIRETHEFT_MALICIOUS";
    public static final String TP_THEFT = "TP_THEFT";
    public static final String UNEMPLOYMENT = "UNEMPLOYMENT";
    public static final String WORLDWIDE = "WORLDWIDE";
  }

  public static class PolicyOptions {

    private PolicyOptions() {}

    public static final String ADVENTURE = "ADVENTURE";
    public static final String AUDIO_SYSTEM_COVER = "AUDIO_SYSTEM_COVER";
    public static final String BREAKDOWN_COVER = "BREAKDOWN_COVER";
    public static final String CONTENTS_COVER = "CONTENTS_COVER";
    public static final String COURTESY_CAR = "COURTESY_CAR";
    public static final String CRITICAL_ILLNESS = "CRITICAL_ILLNESS";
    public static final String DANGEROUS_SPORTS = "DANGEROUS_SPORTS";
    public static final String DENTAL = "DENTAL";
    public static final String DRIVING_ABROAD = "DRIVING_ABROAD";
    public static final String DRIVING_OTHER_CARS = "DRIVING_OTHER_CARS";
    public static final String EMPLOYMENT = "EMPLOYMENT";
    public static final String INCOME_PROTECTION = "INCOME_PROTECTION";
    public static final String LEGAL_COVER = "LEGAL_COVER";
    public static final String MEDICAL = "MEDICAL";
    public static final String NO_CLAIMS_BONUS_PROTECTION = "NO_CLAIMS_BONUS_PROTECTION";
    public static final String OPTICAL = "OPTICAL";
    public static final String PERSONAL_ACCIDENT = "PERSONAL_ACCIDENT";
    public static final String REDUNDANCY = "REDUNDANCY";
    public static final String REPLACEMENT_KEY = "REPLACEMENT_KEY";
    public static final String WINDSCREEN_COVER = "WINDSCREEN_COVER";
  }
}
