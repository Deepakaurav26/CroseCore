package com.experian.eda.crosscore.standardmapper;

import com.experian.eda.crosscore.api.decisionElements.WarningOrError;
import com.experian.eda.crosscore.api.request.RequestMessage;
import com.experian.eda.crosscore.json.CrossCoreObjectMapperFactory;
import com.experian.eda.crosscore.mapper.api.exceptions.MapperException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import lombok.val;

import java.io.IOException;
import java.util.Collections;
import java.util.stream.Collectors;
import javax.validation.Validation;
import javax.validation.Validator;

/**
 * This {@code ParsingTransformer} class is a wrapper {@link Transformer} that is used when we need to convert a
 * raw {@code byte[]} to a {@link RequestMessage}.
 * <p>
 * After it's converted, it is passed to the delegate {@link #inner} Transformer to process further before
 * it is passed to the {@link Transporter}.
 */
@Slf4j
@AllArgsConstructor
public class ParsingTransformer<TransformerResult, Configuration>
    implements Transformer<byte[], TransformerResult, Configuration> {

  /*
   * Nested Transformer class that the ParsingTransformer will delegate to after it has converted the
   * byte[] to a RequestMessage.
   */
  @NonNull
  private final Transformer<RequestMessage, TransformerResult, Configuration> inner;
  /*
   * Preconfigured ObjectMapper class that is used to convert byte[] to RequestMessage.
   */
  private final ObjectMapper objectMapper = CrossCoreObjectMapperFactory.createObjectMapper();

  /*
   * Validation helper class that is used to process constraint validation on RequestMessage.
   */
  private final Validator validator = Validation.buildDefaultValidatorFactory().getValidator();

  /**
   * This {@code transformRequest} method will convert raw {@code byte[]} to {@link RequestMessage} and return the result by delegating
   * the request to {@code inner}.
   * <p>
   * This method will also handle IOException and create an Error response if it fails to convert the {@code byte[]}.
   * Any failed validation check on {@link RequestMessage} will be handled and returned as a collection of Error
   * responses inside a {@link MapperException}
   *
   * @param bytes the CrossCore message in byte[]
   * @param config the Mapper configuration of type Configuration
   * @return the transformer result of type TransformerResult
   * @throws MapperException if a MapperException is thrown by {@code inner#transformRequest}
   */
  @Override
  public TransformerResult transformRequest(@NonNull final byte[] bytes, @NonNull final Configuration config)
      throws MapperException {
    final RequestMessage parsedRequest;
    try {
      parsedRequest = objectMapper.readValue(bytes, RequestMessage.class);
    } catch (IOException e) {
      val message = "Failed to parse request JSON: " + e.getMessage();
      log.error(message, e);
      throw new MapperException(Collections.singletonList(
          WarningOrError
              .builder()
              .responseType(WarningOrError.ResponseType.ERROR)
              .responseMessage(message)
              .build()
      ));
    }
    if (parsedRequest == null) {
      throw new MapperException("request is null");
    }

    val constraintViolations = validator.validate(parsedRequest);
    if (!constraintViolations.isEmpty()) {
      throw new MapperException(
          constraintViolations
              .stream()
              .map(it -> WarningOrError
                  .builder()
                  .responseType(WarningOrError.ResponseType.ERROR)
                  .responseMessage(it.getPropertyPath().toString() + " " + it.getMessage())
                  .build())
              .collect(Collectors.toList()));
    }

    return inner.transformRequest(parsedRequest, config);
  }

  /**
   * Calls {@link #close()} for all the closeable classes after the end of the call.
   *
   * @return void
   * @throws java.lang.Exception if there is a failure to close
   */
  @Override
  public void close() throws Exception {
    inner.close();
  }

}
