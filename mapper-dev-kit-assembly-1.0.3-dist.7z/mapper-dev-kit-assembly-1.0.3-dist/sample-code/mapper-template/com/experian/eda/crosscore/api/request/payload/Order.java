package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.request.payload.contact.MonetaryAmount;
import com.experian.eda.crosscore.api.validation.NotNullElement;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Order {

  private String id;
  private String source;
  private String promoCode;
  private Integer failedPaymentAttempts;
  @Valid
  private List<@NotNullElement LineItem> lineItems;
  @Valid
  private List<@NotNullElement Shipment> shipments;
  private MonetaryAmount totalAmount;
}
