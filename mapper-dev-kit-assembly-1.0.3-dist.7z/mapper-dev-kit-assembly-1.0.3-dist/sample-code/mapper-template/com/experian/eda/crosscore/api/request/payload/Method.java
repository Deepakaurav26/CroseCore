package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.request.payload.contact.Card;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;

/**
 * Class representing the Method of Payment JSON object in a CrossCore message.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Method {

  private String type;
  @JsonProperty(value = "cardId")
  private Card card;
  @JsonProperty(value = "financialAccountId")
  @Valid
  private FinancialAccount financialAccount;
  @JsonProperty(value = "loyaltyProgramId")
  @Valid
  private LoyaltyProgram loyaltyProgram;
  private Authorization authorization;
  private String paymentServiceBrand;
  private String paymentServiceId;

  public static class Type {

    private Type() {}

    public static final String CARD = "CARD";
    public static final String DIRECT_DEBIT = "DIRECT_DEBIT";
    public static final String GIFT_CARD = "GIFT_CARD";
    public static final String INSTANT_CREDIT = "INSTANT_CREDIT";
    public static final String LENDING = "LENDING";
    public static final String LOYALTY = "LOYALTY";
    public static final String OTHER = "OTHER";
    public static final String PAYMENT_SERVICE = "PAYMENT_SERVICE";
    public static final String VOUCHER = "VOUCHER";
  }

  public static class PaymentServiceBrand {

    private PaymentServiceBrand() {}

    public static final String BML = "BML";
    public static final String DBL = "DBL";
    public static final String EBM = "EBM";
    public static final String GGL = "GGL";
    public static final String PPL = "PPL";
  }
}
