package com.experian.eda.crosscore.standardmapper;

import com.experian.eda.crosscore.api.decisionElements.WarningOrError;
import com.experian.eda.crosscore.mapper.api.exceptions.MapperException;
import lombok.NonNull;

import java.util.List;

/**
 * This {@code RetriableMapperException} class in an exception that is thrown when {@link RetryingTransporter}
 * fails and retries according to the configuration set.
 */
public class RetriableMapperException extends MapperException {

  /**
   * Constructs a RetriableMapperException.
   *
   * @param errors the list of errors to show the client and must not be null or empty
   */
  public RetriableMapperException(@NonNull List<WarningOrError> errors) {
    super(errors);
  }

  /**
   * Constructs a RetriableMapperException.
   *
   * @param error an error to show the client and must not be null
   */
  public RetriableMapperException(@NonNull WarningOrError error) {
    super(error);
  }

  public RetriableMapperException(String message) {
    super(message);
  }

}
