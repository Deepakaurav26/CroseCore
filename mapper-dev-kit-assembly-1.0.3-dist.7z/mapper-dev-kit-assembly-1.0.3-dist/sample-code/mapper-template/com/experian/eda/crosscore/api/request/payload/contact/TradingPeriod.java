package com.experian.eda.crosscore.api.request.payload.contact;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TradingPeriod {

  private Integer value;
  private String unit;
}
