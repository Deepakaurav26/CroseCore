package com.experian.eda.crosscore.api.request.payload.contact;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class representing the BiometricData JSON object in a CrossCore message.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BiometricData {

  private String value;
  private String fingerPosition;
  private String type;

  public static class FingerPosition {

    private FingerPosition() {}

    public static final String LEFT_IRIS = "LEFT_IRIS";
    public static final String RIGHT_IRIS = "RIGHT_IRIS";
    public static final String LEFT_INDEX = "LEFT_INDEX";
    public static final String LEFT_LITTLE = "LEFT_LITTLE";
    public static final String LEFT_MIDDLE = "LEFT_MIDDLE";
    public static final String LEFT_RING = "LEFT_RING";
    public static final String LEFT_THUMB = "LEFT_THUMB";
    public static final String RIGHT_INDEX = "RIGHT_INDEX";
    public static final String RIGHT_LITTLE = "RIGHT_LITTLE";
    public static final String RIGHT_MIDDLE = "RIGHT_MIDDLE";
    public static final String RIGHT_RING = "RIGHT_RING";
    public static final String RIGHT_THUMB = "RIGHT_THUMB";
    public static final String UNKNOWN = "UNKNOWN";
  }

  public static class BioType {

    private BioType() {}

    public static final String FMR = "FMR";
    public static final String FIR = "FIR";
    public static final String IIS = "IIS";
  }
}
