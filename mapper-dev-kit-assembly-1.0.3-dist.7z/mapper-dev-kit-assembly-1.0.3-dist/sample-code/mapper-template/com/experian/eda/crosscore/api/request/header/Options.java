package com.experian.eda.crosscore.api.request.header;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.Map;

/**
 * Object representing the Options in the header of the CrossCore message.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Options {

  private String version;
  private String customOption1;
  private String customOption2;
  private String customOption3;
  private String customOption4;
  private String customOption5;
  private String customOption6;
  private String customOption7;

  @Getter(AccessLevel.NONE)
  private Map<String, JsonNode> otherOptions;

  @JsonAnySetter
  public void setOtherOption(String name, JsonNode value) {
    if (this.otherOptions == null) {
      this.otherOptions = new HashMap<>();
    }
    this.otherOptions.put(name, value);
  }

  @JsonAnyGetter
  public Map<String, JsonNode> getOtherOptions() {
    return this.otherOptions;
  }

}
