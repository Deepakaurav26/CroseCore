package com.experian.eda.crosscore.standardmapper;

import com.experian.eda.crosscore.mapper.api.exceptions.MapperException;

/**
 * This {@code Transformer} interface declares the {@code transformRequest} method and is used by
 * {@link StandardMapper}.
 * <p>
 * The {@code transformRequest} operation should define the logic to map a cross core request and convert
 * it to the backing application request.
 *
 * @param <RequestMessage> the class type instance that is transformed to {@literal <TransformerResult>}
 * @param <TransformerResult> the class type that is returned as a result of the transformRequest operation.
 *                            This should represent the request that will be sent to the backing application.
 * @param <Configuration> the class type for {@link MapperConfiguration} and stores the values for all the
 *                        configurations related to the mapper
 */

public interface Transformer<RequestMessage, TransformerResult, Configuration> extends AutoCloseable {

  TransformerResult transformRequest(RequestMessage requestMessage, Configuration config) throws MapperException;
}
