package com.experian.eda.crosscore.api.request.payload;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class KbaAnswers {

  private String outWalletAnswer1;
  private String outWalletAnswer2;
  private String outWalletAnswer3;
  private String outWalletAnswer4;
  private String outWalletAnswer5;
  private String outWalletAnswer6;
  private String outWalletAnswer7;
  private String outWalletAnswer8;
}
