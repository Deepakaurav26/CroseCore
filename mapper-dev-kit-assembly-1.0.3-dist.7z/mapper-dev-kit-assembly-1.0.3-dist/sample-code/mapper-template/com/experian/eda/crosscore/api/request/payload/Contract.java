package com.experian.eda.crosscore.api.request.payload;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;

/**
 * Class representing the Contract JSON object in a CrossCore message.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Contract {

  private String id;
  private String type;
  private String contractType;
  private String status;
  private Integer noOfHandsets;
  private String handsetType;
  private String network;
  private Charges charges;
  private Tariff tariff;
  @Valid
  private Store store;

  public static class Type {

    public static final String INDIVIDUAL = "INDIVIDUAL";
    public static final String COMMERCIAL = "COMMERCIAL";
  }

  public static class ContractType {

    public static final String TELCO = "TELCO";
  }

  public static class Status {

    public static final String EXISTING = "EXISTING";
    public static final String PENDING = "PENDING";
  }

}
