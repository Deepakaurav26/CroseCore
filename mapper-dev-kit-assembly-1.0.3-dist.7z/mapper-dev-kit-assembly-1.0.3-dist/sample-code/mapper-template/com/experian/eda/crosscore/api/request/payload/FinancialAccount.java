package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.request.payload.contact.BankAccount;
import com.experian.eda.crosscore.api.request.payload.contact.Contact;
import com.experian.eda.crosscore.api.validation.NotNullElement;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import javax.validation.Valid;

/**
 * Class representing the Financial Account JSON object in a CrossCore message.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class FinancialAccount {

  private String id;
  private String accountType;
  private String subType;
  private String type;
  private String status;
  private String accountName;
  @Valid
  private List<@NotNullElement AccountHolder> accountHolders;
  private BankAccount bankAccount;
  @JsonProperty(value = "institutionContactId")
  @Valid
  private Contact contact;
  private String lineOfBusiness;

  public static class AccountType {

    private AccountType() {}

    public static final String BANK = "BANK";
    public static final String CREDIT = "CREDIT";
    public static final String CREDITCARD = "CREDITCARD";
    public static final String EXTERNAL = "EXTERNAL";
    public static final String INVESTMENT = "INVESTMENT";
    public static final String ISA = "ISA";
    public static final String LOAN = "LOAN";
    public static final String MORTGAGE = "MORTGAGE";
    public static final String OTHER = "OTHER";
    public static final String SAVINGS = "SAVINGS";
    public static final String SHARE = "SHARE";
    public static final String TELCO_CONTRACT = "TELCO_CONTRACT";
  }

  public static class SubType {

    private SubType() {}

    public static final String CHECKING = "CHECKING";
    public static final String SAVINGS = "SAVINGS";
  }

  public static class Type {

    private Type() {}

    public static final String JOINT = "JOINT";
    public static final String SINGLE = "SINGLE";
  }

  public static class Status {

    private Status() {}

    public static final String EXISTING = "EXISTING";
    public static final String PENDING = "PENDING";
  }

  public static class LineOfBusiness {

    private LineOfBusiness() {}

    public static final String COMMERCIAL = "COMMERCIAL";
  }
}
