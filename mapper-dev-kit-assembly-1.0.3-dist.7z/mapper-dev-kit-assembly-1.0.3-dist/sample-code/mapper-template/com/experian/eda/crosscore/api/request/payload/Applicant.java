package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.request.payload.contact.Contact;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;

/**
 * Class representing the Applicant JSON object in a CrossCore message.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Applicant {

  private String id;
  @JsonProperty(value = "contactId")
  @Valid
  private Contact contact;
  private String type;
  private String applicantType;
  private Boolean consent;
  private Boolean knownCustomer;
  private String roleInAccident;
  @JsonProperty(value = "vehicleId")
  @Valid
  private Vehicle vehicle;

  public static class Type {

    private Type() {}

    public static final String ADD_DRIVER = "ADD_DRIVER";
    public static final String CLAIMANT = "CLAIMANT";
    public static final String COMMERCIAL = "COMMERCIAL";
    public static final String INDIVIDUAL = "INDIVIDUAL";
    public static final String JOINT = "JOINT";
    public static final String MAIN_DRIVER = "MAIN_DRIVER";
    public static final String POLICY_HOLDER = "POLICY_HOLDER";
  }

  public static class ApplicantType {

    private ApplicantType() {}

    public static final String ADDITIONAL_CARDHOLDER = "ADDITIONAL_CARDHOLDER";
    public static final String ADDITIONAL_DRIVER = "ADDITIONAL_DRIVER";
    public static final String APPLICANT = "APPLICANT";
    public static final String APPLYING_ORGANISATION = "APPLYING_ORGANISATION";
    public static final String CLAIMANT = "CLAIMANT";
    public static final String CLAIMANT_ORGANISATION = "CLAIMANT_ORGANISATION";
    public static final String CO_APPLICANT = "CO_APPLICANT";
    public static final String CO_APPLICANT_ORGANIZATION = "CO_APPLICANT_ORGANIZATION";
    public static final String COMPANY_SECRETARY = "COMPANY_SECRETARY";
    public static final String DIRECTOR = "DIRECTOR";
    public static final String GUARANTOR = "GUARANTOR";
    public static final String GUARANTOR_ORGANIZATION = "GUARANTOR_ORGANIZATION";
    public static final String JOINT_APPLICANT = "JOINT_APPLICANT";
    public static final String MAIN_APPLICANT = "MAIN_APPLICANT";
    public static final String POLICY_HOLDER = "POLICY_HOLDER";
    public static final String POLICY_HOLDER_ORGANISATION = "POLICY_HOLDER_ORGANISATION";
  }

  public static class RoleInAccident {

    private RoleInAccident() {}

    public static final String CLAIMANT = "CLAIMANT";
    public static final String CYCLIST = "CYCLIST";
    public static final String DRIVER = "DRIVER";
    public static final String DRIVER_NOT_KNOWN = "DRIVER_NOT_KNOWN";
    public static final String OTHER = "OTHER";
    public static final String OTHER_INJURED_PERSON = "OTHER_INJURED_PERSON";
    public static final String OWNER = "OWNER";
    public static final String PASSENGER_INSURED_VEHICLE = "PASSENGER_INSURED_VEHICLE";
    public static final String PASSENGER_OTHER_VEHICLE = "PASSENGER_OTHER_VEHICLE";
    public static final String PEDESTRIAN = "PEDESTRIAN";
    public static final String POLICYHOLDER = "POLICYHOLDER";
    public static final String POLICYHOLDER_CLAIMANT = "POLICYHOLDER_CLAIMANT";
    public static final String POLICYHOLDER_DRIVER = "POLICYHOLDER_DRIVER";
    public static final String PREMIUM_PAYER = "PREMIUM_PAYER";
    public static final String RIDER = "RIDER";
    public static final String THIRD_PARTY = "THIRD_PARTY";
  }
}
