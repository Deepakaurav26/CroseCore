package com.experian.eda.crosscore.api.request.payload;

import com.experian.eda.crosscore.api.DateFormats;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.DateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class KbaUserDefinedDates {

  @JsonFormat(pattern = DateFormats.DAY)
  private DateTime userDefinedDate1;
  @JsonFormat(pattern = DateFormats.DAY)
  private DateTime userDefinedDate2;
}
