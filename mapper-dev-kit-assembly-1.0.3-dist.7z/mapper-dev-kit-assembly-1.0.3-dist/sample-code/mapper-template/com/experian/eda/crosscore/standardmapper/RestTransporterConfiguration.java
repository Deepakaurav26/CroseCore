package com.experian.eda.crosscore.standardmapper;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.util.StdConverter;
import com.google.common.base.Throwables;
import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Arrays;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/**
 * This {@code ResTransporterConfiguration} class is a configuration class used to configure the OkHttpClient
 * inside {@link RestTransporter#transport}.
 * <p>
 * It is also responsible for instantiating an instance of {@link SSLSocketFactory} if {@code trustStore} and
 * {@code keyStore} values are not null.
 */
@JsonDeserialize(converter = RestTransporterConfiguration.CustomMapperConfigurationConverter.class)
@Data
@NoArgsConstructor
@EqualsAndHashCode(exclude = {"sslSocketFactory"})
public class RestTransporterConfiguration {

  @SuppressFBWarnings(value = {"EI_EXPOSE_REP", "EI_EXPOSE_REP2"},
      justification = "Can't use immutable collection for this field, must be a byte array.")
  byte[] clientTrustStore;
  String clientTrustStoreType;
  String clientTrustStorePassword;
  @SuppressFBWarnings(value = {"EI_EXPOSE_REP", "EI_EXPOSE_REP2"},
      justification = "Can't use immutable collection for this field, must be a byte array.")
  byte[] clientKeyStore;
  String clientKeyStoreType;
  String clientKeyStorePassword;
  /*
   * HttpClient connection timeout in milliseconds with a default value of 10 seconds
   */
  @NotNull
  @Min(value = 0)
  Integer connectTimeoutMillis = 10_000;
  /*
   * HttpClient read timeout in milliseconds with a default value of 10 seconds
   */
  @NotNull
  @Min(value = 0)
  Integer readTimeoutMillis = 10_000;
  /*
   * HttpClient write timeout in milliseconds with a default value of 10 seconds
   */
  @NotNull
  @Min(value = 0)
  Integer writeTimeoutMillis = 10_000;
  /*
   * This is utilized by OkHttpClient in {@link RestTransporter} if not null
   */
  @JsonIgnore
  SSLSocketFactory sslSocketFactory;

  @JsonIgnore
  private static final String ALGORITHM = "TLSv1.2";

  /**
   * This {@code CustomMapperConfigurationConverter} static class is used for post-construct property settings.
   */
  public static class CustomMapperConfigurationConverter
      extends StdConverter<RestTransporterConfiguration, RestTransporterConfiguration> {

    /**
    * This {@code convert} method ...
    *
    * @param
    * @return
    * @throws
    */

    @Override
    public RestTransporterConfiguration convert(RestTransporterConfiguration configuration) {
      configuration.sslSocketFactory = configuration.createSslContextForOkHttp();
      return configuration;
    }
  }

  /*
   * Returns an instance of SSLSocketFactory using trustStore and keyStore properties. Default instance of
   * the same if trustStore properties are null.
   */
  private SSLSocketFactory createSslContextForOkHttp() {
    try {
      if (
          clientTrustStore == null ||
          clientTrustStoreType == null ||
          clientTrustStorePassword == null) {
        return SSLContext.getDefault().getSocketFactory();
      }

      // trust store holding server public key
      final KeyStore trustStore = KeyStore.getInstance(clientTrustStoreType);
      trustStore.load(new ByteArrayInputStream(clientTrustStore), clientTrustStorePassword.toCharArray());
      final TrustManagerFactory trustManagerFactory =
          TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
      trustManagerFactory.init(trustStore);
      final TrustManager[] trustManagers = trustManagerFactory.getTrustManagers();
      if (trustManagers.length != 1 || !(trustManagers[0] instanceof X509TrustManager)) {
        throw new IllegalStateException("Unexpected default trust managers: " + Arrays.toString(trustManagers));
      }

      // key store with client private key
      KeyManager[] keyManagers = null;
      if (clientKeyStore != null &&
          clientKeyStoreType != null &&
          clientKeyStorePassword != null) {
        final KeyStore keyStore = KeyStore.getInstance(clientKeyStoreType);
        keyStore.load(new ByteArrayInputStream(clientKeyStore), clientKeyStorePassword.toCharArray());
        final KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        keyManagerFactory.init(keyStore, clientKeyStorePassword.toCharArray());
        keyManagers = keyManagerFactory.getKeyManagers();
      }

      final SSLContext sslContext = SSLContext.getInstance(ALGORITHM);
      sslContext.init(keyManagers, trustManagers, null);
      return sslContext.getSocketFactory();
    } catch (IOException | CertificateException | NoSuchAlgorithmException | UnrecoverableKeyException | KeyStoreException
        | KeyManagementException e) {
      Throwables.propagateIfPossible(Throwables.getRootCause(e), RuntimeException.class);
    }
    return null;
  }
}
