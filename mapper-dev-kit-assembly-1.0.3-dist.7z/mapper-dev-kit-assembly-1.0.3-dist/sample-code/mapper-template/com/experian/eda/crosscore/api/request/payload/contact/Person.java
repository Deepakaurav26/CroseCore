package com.experian.eda.crosscore.api.request.payload.contact;

import com.experian.eda.crosscore.api.validation.NotNullElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import javax.validation.Valid;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Person {

  private String typeOfPerson;
  private String personIdentifier;
  private PersonDetails personDetails;
  @Valid
  private List<@NotNullElement Name> names;

  public static class TypeOfPerson {

    private TypeOfPerson() {}

    public final static String ACCOUNTANT = "ACCOUNTANT";
    public final static String ADD_DRIVER = "ADD_DRIVER";
    public final static String APPLICANT = "APPLICANT";
    public final static String CLAIMANT = "CLAIMANT";
    public final static String CO_APPLICANT = "CO_APPLICANT";
    public final static String EMPLOYER = "EMPLOYER";
    public final static String GUARANTOR = "GUARANTOR";
    public final static String MAIN_DRIVER = "MAIN_DRIVER";
    public final static String POLICY_HOLDER = "POLICY_HOLDER";
    public final static String PRINCIPLE = "PRINCIPLE";
    public final static String RELATIVE = "RELATIVE";
    public final static String SALES_AGENT = "SALES_AGENT";
    public final static String WITNESS = "WITNESS";
  }
}
