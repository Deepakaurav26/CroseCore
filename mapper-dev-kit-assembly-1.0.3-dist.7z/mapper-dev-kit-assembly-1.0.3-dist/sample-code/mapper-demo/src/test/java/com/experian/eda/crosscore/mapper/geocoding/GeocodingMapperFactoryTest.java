package com.experian.eda.crosscore.mapper.geocoding;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;
import static org.mockito.Mockito.mock;

import com.experian.eda.crosscore.mapper.api.Mapper;
import com.experian.eda.crosscore.mapper.api.MapperResponse;
import com.experian.eda.crosscore.mapper.api.Services;
import com.experian.eda.crosscore.mapper.api.exceptions.MapperException;
import com.experian.eda.crosscore.standardmapper.RestTransporter;
import com.experian.eda.crosscore.standardmapper.RestTransporterConfiguration;
import com.experian.eda.crosscore.standardmapper.RetriableMapperException;
import com.experian.eda.crosscore.standardmapper.RetryingTransporterConfiguration;
import com.experian.eda.crosscore.standardmapper.request.RequestContainer;
import com.experian.eda.crosscore.standardmapper.request.RestPostRequestContainer;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import com.github.tomakehurst.wiremock.junit.WireMockRule;
import lombok.val;
import okhttp3.OkHttpClient;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Map;

public class GeocodingMapperFactoryTest {

  private final GeocodingMapperFactory mapperFactory = new GeocodingMapperFactory();

  private final OkHttpClient okHttpClient = new OkHttpClient.Builder().build();
  private final RestTransporter<RequestContainer<Object>, Map, Object, GeocodingMapperConfig> restTransporter =
      new RestTransporter<>(GeocodingMapperFactory.configuredGeocodingObjectMapper(), Map.class, okHttpClient);

  @Rule
  public WireMockRule wireMockRule = new WireMockRule(
      WireMockConfiguration
          .options()
          .dynamicPort()
          .dynamicHttpsPort());

  private final Mapper<GeocodingMapperConfig> mapper = mapperFactory.createMapper(mock(Services.class));

  private GeocodingMapperConfig getGeocodingMapperConfig() {
    return GeocodingMapperConfig
        .builder()
        .endpoint("http://localhost:" + wireMockRule.port() + "/maps/api/geocode/json")
        .apiKey("440912104240420key")
        .restTransporter(new RestTransporterConfiguration())
        .retryingTransporter(new RetryingTransporterConfiguration())
        .build();
  }

  @Test
  public void testMapperInformation() {
    val mapperInformation = mapperFactory.getMapperInformation();
    Assert.assertEquals("Geocoding", mapperInformation.getName());
    Assert.assertEquals(Collections.singletonList("1"), mapperInformation.getSupportedBackingApplicationVersions());
  }

  @Test
  public void testCreateMapper() {
    val mapper = new GeocodingMapperFactory().createMapper(null);
    Assert.assertNotNull(mapper);
  }

  private static byte[] readFile(final String fileName) {
    try {
      return Files.readAllBytes(Paths.get(ClassLoader.getSystemResource(fileName).toURI()));
    } catch (URISyntaxException | IOException e) {
      throw new RuntimeException(e);
    }
  }

  /**
   * End to end test using wire mock
   */
  @Test
  public void success() throws IOException, MapperException {
    stubFor(get(urlPathMatching("/maps/api/geocode/json?.*"))
                .willReturn(aResponse().withStatus(200)
                                       .withBody(readFile("sample-response.json"))));

    Mapper<GeocodingMapperConfig> mapper = (new GeocodingMapperFactory()).createMapper(null);
    MapperResponse mapperResponse = mapper.call(readFile("sample-request.json"), getGeocodingMapperConfig());
    Assert.assertEquals("ROOFTOP", mapperResponse.getStrategyResponse().get(0));
    Assert.assertEquals("subpremise", mapperResponse.getStrategyResponse().get(1));
  }

  @Test(expected = MapperException.class)
  public void testStatusIncomplete() throws IOException, MapperException {
    stubFor(get(urlPathMatching("/maps/api/geocode/json?.*"))
                .willReturn(aResponse().withStatus(200).withBody("{\"status\": \"incomplete\"}")));
    mapper.call(readFile("sample-request.json"), getGeocodingMapperConfig());
  }

}
