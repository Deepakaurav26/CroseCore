package com.experian.eda.crosscore.mapper.geocoding;

import com.experian.eda.crosscore.mapper.api.exceptions.MapperException;
import com.experian.eda.crosscore.standardmapper.ParsingTransformer;
import com.experian.eda.crosscore.standardmapper.request.RestGetRequestContainer;
import lombok.val;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class GeocodingTransformerTest {

  @Test
  public void testTransform() throws MapperException, IOException {
    val request = Files.readAllBytes(Paths.get("src/test/resources/sample-request.json"));
    val config = GeocodingMapperConfig
        .builder()
        .endpoint("http://example.com")
        .apiKey("secret")
        .build();
    val transformer = new ParsingTransformer<RestGetRequestContainer<Object>, GeocodingMapperConfig>(
        new GeocodingTransformer());
    val container = transformer.transformRequest(request, config);
    Assert.assertEquals(
        "http://example.com?address=16260+N+71st+St+Suite+400+Scottsdale+AZ+85254&key=secret",
        container.getEndPoint());
  }
}
