package com.experian.eda.crosscore.mapper.geocoding

import static org.junit.Assume.assumeTrue
import static org.mockito.Mockito.mock

import com.experian.eda.crosscore.api.decisionElements.DecisionElements
import com.experian.eda.crosscore.mapper.api.Services
import org.junit.Before
import org.junit.Test

/**
 * Example test, where you can plug in real key and see it working.
 * Get key https://developers.google.com/maps/documentation/geocoding/get-api-key
 * Check out existing keys at https://console.developers.google.com/apis/credentials
 * Set the GEOCODING_API_KEY environment variable to your api key.
 */
class GeocodingMapperIntegrationTest {

  final unit = new GeocodingMapperFactory().createMapper(mock(Services))
  final apiKey = System.getenv('GEOCODING_API_KEY')

  @Before
  void assumptions() {
    assumeTrue('GEOCODING_API_KEY not set', apiKey != null)
  }

  @Test
  void test() {
    final request = new File('src/test/resources/sample-request.json').bytes
    final config = new GeocodingMapperConfig(
      endpoint: 'https://maps.googleapis.com/maps/api/geocode/json',
      apiKey: apiKey
    )
    final response = unit.call(request, config)
    assert response.decisionElements == [
      new DecisionElements(
        otherData: [
          response: [
            status: 'OK',
            results: [
              [
                geometry: [
                  location_type: 'ROOFTOP'
                ],
                types: [
                  'subpremise'
                ]
              ]
            ]
          ]
        ]
      )
    ]
  }

}
