package com.experian.eda.crosscore.mapper.geocoding

import com.experian.eda.crosscore.commons.jsontest.ConstraintViolation
import com.experian.eda.crosscore.commons.jsontest.JacksonPojoTest
import org.hibernate.validator.constraints.NotBlank
import org.junit.Test

import javax.validation.constraints.NotNull

class GeocodingMapperConfigTest extends JacksonPojoTest<GeocodingMapperConfig> {
  @Override
  GeocodingMapperConfig getUnit() {
    return new GeocodingMapperConfig(
      endpoint: "https://maps.googleapis.com/maps/api/geocode/json",
      apiKey: 'API-KEY'
    )
  }

  @Override
  String getJson() {
    return '''
      {
        "endpoint": "https://maps.googleapis.com/maps/api/geocode/json",
        "apiKey": "API-KEY",
        "restTransporter": {
          "readTimeoutMillis": 10000,
          "writeTimeoutMillis": 10000,
          "connectTimeoutMillis": 10000
        },
        "retryingTransporter": {
          "maxTries": 3,
          "maxDelayMillis": 1000,
          "baseDelayMillis": 100,
          "exponentialRetryStrategy": false
        }
      }
    '''
  }

  @Test
  void missingFields() {
    runValidationTest(
      new GeocodingMapperConfig(),
      [
        new ConstraintViolation('endpoint', NotBlank),
        new ConstraintViolation('apiKey', NotBlank),
      ])
  }

  @Test
  void defaultFieldsSetToNull() {
    runValidationTest(
      new GeocodingMapperConfig(
        restTransporter: null,
        retryingTransporter: null
      ), [
        new ConstraintViolation('endpoint', NotBlank),
        new ConstraintViolation('apiKey', NotBlank),
        new ConstraintViolation('restTransporter', NotNull),
        new ConstraintViolation('retryingTransporter', NotNull),
      ])
  }
}