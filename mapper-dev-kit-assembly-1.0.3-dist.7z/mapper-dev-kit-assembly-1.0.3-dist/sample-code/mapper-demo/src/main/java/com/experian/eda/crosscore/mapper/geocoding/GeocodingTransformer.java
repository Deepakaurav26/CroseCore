package com.experian.eda.crosscore.mapper.geocoding;

import com.experian.eda.crosscore.api.request.RequestMessage;
import com.experian.eda.crosscore.api.request.payload.Payload;
import com.experian.eda.crosscore.api.request.payload.contact.Address;
import com.experian.eda.crosscore.api.request.payload.contact.Contact;
import com.experian.eda.crosscore.mapper.api.exceptions.MapperException;
import com.experian.eda.crosscore.standardmapper.Transformer;
import com.experian.eda.crosscore.standardmapper.request.RestGetRequestContainer;
import com.experian.eda.crosscore.standardmapper.request.RestPostRequestContainer;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class GeocodingTransformer
    implements Transformer<RequestMessage, RestGetRequestContainer<Object>, GeocodingMapperConfig> {

  @Override
  public RestGetRequestContainer<Object> transformRequest(
      final RequestMessage requestMessage, final GeocodingMapperConfig config) throws MapperException {
    // Get the first address of the first contact
    final Address address = Optional
        .of(requestMessage)
        .map(RequestMessage::getPayload)
        .map(Payload::getContacts)
        .flatMap(contacts -> contacts.stream().findFirst())
        .map(Contact::getAddresses)
        .flatMap(addresses -> addresses.stream().findFirst())
        .orElseThrow(() -> new MapperException("Missing addresses in contact"));
    final String addressString = Stream
        .of(
            address.getBuildingNumber(),
            address.getStreet(),
            address.getPostTown(),
            address.getStateProvinceCode(),
            address.getPostal())
        .map(StringUtils::trimToNull)
        .filter(Objects::nonNull)
        .collect(Collectors.joining(" "));
    final String finalUri = config
        .getEndpoint()
        .concat("?")
        .concat(URLEncodedUtils.format(
            Arrays.asList(
                new BasicNameValuePair("address", addressString),
                new BasicNameValuePair("key", config.getApiKey())),
            StandardCharsets.UTF_8));
    return RestGetRequestContainer
        .builder()
        .endPoint(finalUri)
        .build();
  }

  @Override
  public void close() throws Exception {
    // do nothing
  }
}
