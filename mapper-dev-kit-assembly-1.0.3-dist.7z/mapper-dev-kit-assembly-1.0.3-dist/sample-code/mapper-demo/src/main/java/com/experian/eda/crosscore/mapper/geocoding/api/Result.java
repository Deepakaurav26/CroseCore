package com.experian.eda.crosscore.mapper.geocoding.api;

import lombok.Value;

import java.util.List;

@Value
public class Result {

  Geometry geometry;
  List<String> types;
}
