package com.experian.eda.crosscore.mapper.geocoding;

import com.experian.eda.crosscore.mapper.api.Mapper;
import com.experian.eda.crosscore.mapper.api.MapperFactory;
import com.experian.eda.crosscore.mapper.api.MapperInformation;
import com.experian.eda.crosscore.mapper.api.Services;
import com.experian.eda.crosscore.mapper.geocoding.api.GeocodingResponse;
import com.experian.eda.crosscore.standardmapper.ParsingTransformer;
import com.experian.eda.crosscore.standardmapper.PojoConfigurationReader;
import com.experian.eda.crosscore.standardmapper.RestTransporter;
import com.experian.eda.crosscore.standardmapper.RetryingTransporter;
import com.experian.eda.crosscore.standardmapper.StandardMapper;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.joda.JodaModule;
import lombok.val;

import java.util.Collections;
import java.util.TimeZone;

/**
 * Factory producing the Geocoding mapper
 */
public class GeocodingMapperFactory implements MapperFactory<Mapper<GeocodingMapperConfig>> {

  @Override
  public Mapper<GeocodingMapperConfig> createMapper(final Services services) {
    val geocodingObjectMapper = configuredGeocodingObjectMapper();
    return new StandardMapper<>(
        new PojoConfigurationReader<>(GeocodingMapperConfig.class),
        new ParsingTransformer<>(new GeocodingTransformer()),
        new RetryingTransporter<>(
            new RestTransporter<>(geocodingObjectMapper, GeocodingResponse.class)
        ),
        new GeocodingResponseGenerator(geocodingObjectMapper)
    );
  }

  @Override
  public MapperInformation getMapperInformation() {
    return MapperInformation
        .builder()
        .name("Geocoding")
        .supportedBackingApplicationVersions(Collections.singletonList("1"))
        .build();
  }

  public static ObjectMapper configuredGeocodingObjectMapper() {
    final ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.registerModule(new JodaModule());
    objectMapper.configure(MapperFeature.AUTO_DETECT_IS_GETTERS, false);
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    objectMapper.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true);
    objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    objectMapper.setTimeZone(TimeZone.getTimeZone("UTC"));
    return objectMapper;
  }
}
