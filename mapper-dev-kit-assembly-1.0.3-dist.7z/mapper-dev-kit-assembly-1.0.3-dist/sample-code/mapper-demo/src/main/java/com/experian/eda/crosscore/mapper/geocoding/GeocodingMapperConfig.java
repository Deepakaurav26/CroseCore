package com.experian.eda.crosscore.mapper.geocoding;

import com.experian.eda.crosscore.standardmapper.RestTransporterConfiguration;
import com.experian.eda.crosscore.standardmapper.RestTransporterConfigurationProvider;
import com.experian.eda.crosscore.standardmapper.RetryingTransporterConfiguration;
import com.experian.eda.crosscore.standardmapper.RetryingTransporterConfigurationProvider;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.hibernate.validator.constraints.NotBlank;

/**
 * Geocoding mapper configuration
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@FieldDefaults(level = AccessLevel.PRIVATE)
public class GeocodingMapperConfig implements RestTransporterConfigurationProvider,
                                              RetryingTransporterConfigurationProvider {

  // @NotNull & @Valid come from the *Provider interfaces
  RestTransporterConfiguration restTransporter = new RestTransporterConfiguration();
  RetryingTransporterConfiguration retryingTransporter = new RetryingTransporterConfiguration();

  @NotBlank
  String endpoint;

  @NotBlank
  String apiKey;
}