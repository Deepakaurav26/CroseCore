package com.experian.eda.crosscore.mapper.geocoding.api;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Value;

@Value
public class Geometry {

  @JsonProperty("location_type")
  String locationType;
}
