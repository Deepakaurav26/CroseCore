package com.experian.eda.crosscore.mapper.geocoding;

import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import com.experian.eda.crosscore.api.decisionElements.DecisionElements;
import com.experian.eda.crosscore.mapper.api.MapperResponse;
import com.experian.eda.crosscore.mapper.api.exceptions.MapperException;
import com.experian.eda.crosscore.mapper.geocoding.api.GeocodingResponse;
import com.experian.eda.crosscore.mapper.geocoding.api.Geometry;
import com.experian.eda.crosscore.mapper.geocoding.api.Result;
import com.experian.eda.crosscore.standardmapper.ResponseGenerator;
import com.experian.eda.crosscore.standardmapper.RestResponseContainer;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import lombok.val;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@AllArgsConstructor
public class GeocodingResponseGenerator
    implements ResponseGenerator<RestResponseContainer<GeocodingResponse, Object>, GeocodingMapperConfig> {

  @NonNull
  private final ObjectMapper objectMapper;

  @Override
  public MapperResponse generateResponse(
      final RestResponseContainer<GeocodingResponse, Object> transporterResult,
      final GeocodingMapperConfig config) throws MapperException {
    val geocodingResponse = transporterResult.getBody();
    if (!StringUtils.equals("OK", geocodingResponse.getStatus())) {
      throw new MapperException("Request failed: " + trimToEmpty(geocodingResponse.getStatus()));
    }
    return MapperResponse
        .builder()
        .decisionElements(Collections.singletonList(
            DecisionElements
                .builder()
                .otherData(
                    Collections.singletonMap("response", objectMapper.convertValue(geocodingResponse, Map.class)))
                .build()))
        .strategyResponse(buildStrategyResponse(geocodingResponse))
        .build();
  }

  /**
   * Build strategy response with key element values for CrossCore's Strategy Manager. These values will be used by
   * Strategy Manager to make decisions. For example, if Strategy Manager finds location or premiseType as "", it may
   * consider it unfavorable for the CrossCore client.
   */
  private List<String> buildStrategyResponse(final GeocodingResponse geocodingResponse) {
    final Optional<Result> firstResult = Optional
        .ofNullable(geocodingResponse.getResults())
        .flatMap(it -> it.stream().findFirst());
    return Arrays.asList(
        firstResult.map(Result::getGeometry).map(Geometry::getLocationType).orElse(EMPTY),
        firstResult.map(Result::getTypes).flatMap(it -> it.stream().findFirst()).orElse(EMPTY)
    );
  }

  @Override
  public void close() throws Exception {
    // do nothing
  }
}
