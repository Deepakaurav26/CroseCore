#!/usr/bin/env bash
set -e

mapper="Geocoding"
json="sample-request.json"

# send to mapper
docker-compose exec mapper-service-client-cli mapper-service-client-cli --mapper $mapper --file $(pwd)/$json
