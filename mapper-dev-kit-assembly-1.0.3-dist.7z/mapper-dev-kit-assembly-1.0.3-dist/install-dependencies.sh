#!/usr/bin/env bash

mvn_command="mvn"
command -v "${mvn_command}" >/dev/null 2>&1 || { echo >&2 "Cannot find ${mvn_command}. Aborting."; exit 1; }

# default dir
jars_dir="./jars"
if [ ! -d "${jars_dir}" ]
then
  echo "Directory ${jars_dir} does not exist. Aborting."
  exit 1
fi

install_file() {
  "${mvn_command}" install:install-file "$@"
}

# get list of .pom
for pom in $(ls -1 ${jars_dir}/*.pom)
do
  prefix="${pom%.*}"
  jar="${prefix}.jar"
  javadoc="${prefix}-javadoc.jar"
  sources="${prefix}-sources.jar"
  if [ -f "${jar}" ]
  then
    if [ -f "${sources}" ]
    then
      if [ -f "${javadoc}" ]
      then
        install_file -DpomFile="${pom}" -Dfile="${jar}" -Djavadoc="${javadoc}" -Dsources="${sources}"
      else
        install_file -DpomFile="${pom}" -Dfile="${jar}" -Dsources="${sources}"
      fi
    else
      install_file -DpomFile="${pom}" -Dfile="${jar}"
    fi
  else
    install_file -DpomFile="${pom}" -Dfile="${pom}"
  fi
done
